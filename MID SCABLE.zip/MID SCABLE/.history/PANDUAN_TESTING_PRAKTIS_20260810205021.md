# 📋 PANDUAN TESTING PRAKTIS
## Web Sekolah Terintegrasi - Kelompok 2, 6B RPL

**Tanggal**: August 10, 2026  
**Tujuan**: Panduan step-by-step praktis untuk menjalankan semua jenis testing

⚠️ **STATUS IMPLEMENTASI**:
- ✅ Postman API Tests: Siap digunakan
- ⏳ PHPUnit Tests: Template ada, perlu diimplementasikan
- ⏳ JMeter Load Tests: Perlu dibuat
- ⏳ Cypress E2E Tests: Perlu diimplementasikan

---

## 🎯 QUICK REFERENCE - JENIS TESTING

| Jenis Testing | Tools | Durasi | Link |
|---|---|---|---|
| **Unit Testing** | PHPUnit | 2 menit | [Lihat Panduan](#-unit-testing) |
| **Integration Testing** | PHPUnit | 2 menit | [Lihat Panduan](#-integration-testing) |
| **API Testing** | Postman | 5 menit | [Lihat Panduan](#-api-testing-postman) |
| **Load Testing** | JMeter | 10 menit | [Lihat Panduan](#-load-testing-jmeter) |
| **E2E Testing** | Cypress | 5 menit | [Lihat Panduan](#-e2e-testing-cypress) |
| **Manual Testing** | Browser | 30 menit | [Lihat Panduan](#-manual-testing-system) |

---

## ✅ PERSIAPAN AWAL (Lakukan 1x)

### 1. Setup Database

```bash
# Buka terminal/CMD di folder project
cd "c:\xampp\htdocs\MID SCABLE"

# Import database
mysql -u root < database/database.sql

# Verifikasi
mysql -u root -e "SHOW DATABASES;"
# Pastikan ada database: school_attendance
```

### 2. Install Dependencies

```bash
# Install Composer dependencies
composer install

# Install NPM dependencies
npm install
```

### 3. Start Web Server

```bash
# Jalankan server PHP
php -S localhost:8000

# Biarkan terminal terbuka (jangan ditutup!)
# Server akan berjalan di: http://localhost:8000
```

### 4. Verifikasi Setup

```bash
# Buka browser, akses:
http://localhost:8000/index.php

# Jika melihat login page → Setup OK ✅
```

---

## 🧪 UNIT TESTING

### Perintah Cepat

```bash
# Jalankan semua unit tests
./vendor/bin/phpunit tests/Unit/

# Dengan coverage report (hasilnya di folder "coverage")
./vendor/bin/phpunit --coverage-html coverage/ tests/Unit/
```

### Langkah Eksekusi

```
1. Terminal sudah buka di project folder? ✓
2. Ketik: ./vendor/bin/phpunit tests/Unit/
3. Tekan Enter
4. Tunggu 1-2 menit
```

### Output yang Diharapkan

```
PHPUnit 9.5.x by Sebastian Bergmann

AuthenticationTest
 ✓ testValidLoginWithCorrectCredentials
 ✓ testLoginWithInvalidPassword
 ✓ testPasswordHashingUsesBcrypt

StudentManagementTest
 ✓ testAddValidStudent
 ✓ testDuplicateNISRejected
 ✓ testUpdateStudentData

AttendanceTest
 ✓ testRecordValidAttendance
 ✓ testInvalidStatusRejected

...

OK (42 tests, 250 assertions)
Coverage: 72% ✅
```

### Lihat Hasil Coverage Lebih Detail

```bash
# Jalankan dengan coverage
./vendor/bin/phpunit --coverage-html coverage/ tests/Unit/

# Buka folder "coverage" di project
# Buka file: coverage/index.html
# Lihat coverage per file
```

---

## 🔗 INTEGRATION TESTING

### Perintah Cepat

```bash
# Jalankan integration tests
./vendor/bin/phpunit tests/Integration/
```

### Langkah Eksekusi

```
1. Pastikan unit tests sudah jalan sebelumnya
2. Ketik: ./vendor/bin/phpunit tests/Integration/
3. Tekan Enter
4. Tunggu 1-2 menit
```

### Output yang Diharapkan

```
PHPUnit 9.5.x by Sebastian Bergmann

LoginDashboardTest
 ✓ testLoginToDashboardFlow

AddStudentDisplayTest
 ✓ testAddStudentAndDisplay

AttendanceReportTest
 ✓ testInputAttendanceAndReport

PermissionTest
 ✓ testTeacherCannotAccessAdminPanel

ScheduleValidationTest
 ✓ testScheduleToAttendanceValidation

DataIntegrityTest
 ✓ testCrossModuleDataIntegrity

OK (6 tests)
Coverage: 60% ✅
```

---

## 📮 API TESTING (POSTMAN)

### Step 1: Buka Postman

```
1. Buka aplikasi Postman
   (atau akses: https://web.postman.co)
2. Login dengan akun Postman
3. Siap untuk import collection
```

### Step 2: Import Collection

```
File → Import
↓
Pilih file: 03_Test_Scripts_and_Automation/Postman_API_Collection.json
↓
Klik Import
```

### Step 3: Setup Environment

```
1. Klik "Environments" di kiri
2. Klik "Create New"
3. Name: "ASTQA Testing"
4. Tambah variables:
   
   Variable Name: BASE_URL
   Value: http://localhost:8000/MID SCABLE
   
   Variable Name: session_token
   Initial Value: (kosongkan, auto-filled)
```

### Step 4: Jalankan Collection

```
1. Klik "Collections" → "Postman_API_Collection"
2. Klik tombol ▶️ "Run"
3. Pastikan environment: "ASTQA Testing" terpilih
4. Klik "Run Collection"
5. Tunggu selesai (2-3 menit)
```

### Expected Results

```
Total requests: 20+
Passed: 20+ ✅
Failed: 0
Duration: 2-3 minutes

Test categories:
✅ Authentication (4 tests)
✅ User Management (4 tests)
✅ Student Management (4 tests)
✅ Attendance (3 tests)
✅ Reports (2 tests)
✅ Security Tests (3 tests)
```

### Tips

- Jika ada error "Cannot read property 'session_token'", jalankan ulang - login test berjalan dulu
- Jika error connection refused, pastikan web server masih running
- Response time rata-rata: 200-300ms normal ✓

---

## ⚡ LOAD TESTING (JMETER)

### Step 1: Buka JMeter

```bash
# Windows
jmeter.bat

# macOS/Linux
jmeter
```

### Step 2: Load Test Plan

```
File → Open → JMeter_Load_Test_Plan.jmx

Atau buat baru:
1. File → New
2. Add Thread Group (Kanan klik → Add → Threads → Thread Group)
3. Setup:
   - Number of Threads: 100
   - Ramp-up: 10 seconds
   - Loop Count: 5
```

### Step 3: Setup Request

```
Thread Group → Add → Sampler → HTTP Request

Isi:
- Server Name: localhost
- Port: 8000
- Path: /MID SCABLE/admin/dashboard.php
- Method: GET
```

### Step 4: Add Listeners (untuk lihat hasil)

```
Thread Group → Add → Listener → Aggregate Report
Thread Group → Add → Listener → Graph Results
Thread Group → Add → Listener → View Results Tree
```

### Step 5: Jalankan

```
Klik tombol ▶️ START
Tunggu hingga selesai (5-10 menit)
Lihat results di tab Aggregate Report
```

### Expected Results

```
Dashboard Load Test (100 users):
- Sample Count: 500
- Average Response Time: 280ms ✅ (target: < 500ms)
- Min: 45ms
- Max: 890ms
- 95th Percentile: 650ms
- Error Rate: < 1% ✅

Status: PASS ✅
```

---

## 🎯 E2E TESTING (CYPRESS)

### Step 1: Terminal - Pilih Mode

**Mode A: GUI (Interactive)**
```bash
npx cypress open
```

**Mode B: Headless (Automated)**
```bash
npx cypress run
```

### Step 2: GUI Mode (Rekomendasi untuk Pertama Kali)

```
npx cypress open
↓
Pilih "E2E Testing"
↓
Pilih Browser (Chrome/Firefox/Edge)
↓
Pilih test file (misal: 1_login.cy.js)
↓
Test berjalan otomatis ▶️
```

### Step 3: Headless Mode (untuk hasil cepat)

```bash
npx cypress run

# Expected output:
# Running:  1_login.cy.js        (1 of 5)
#   ✓ Admin can login successfully (2.5s)
#   ✓ Teacher can login successfully (2.3s)
#   ✓ Invalid login shows error (0.8s)
#
# Running:  2_student.cy.js       (2 of 5)
#   ✓ Admin can add student (3.0s)
#   ✓ Student list filters correctly (1.5s)
#
# Running:  3_attendance.cy.js    (3 of 5)
#   ✓ Teacher can input attendance (2.8s)
#   ✓ All students marked correctly (2.0s)
#
# ...
# All specs passed! (10 tests)
# Duration: 2m 15s
```

### Step 4: Jalankan Specific Test

```bash
# Hanya login tests
npx cypress run --spec "cypress/e2e/1_login.cy.js"

# Hanya attendance tests
npx cypress run --spec "cypress/e2e/3_attendance.cy.js"

# Dengan browser tertentu
npx cypress run --browser chrome
```

### Expected Results

```
✅ Login Tests (3 tests)
  ✓ Admin login success
  ✓ Teacher login success
  ✓ Invalid login rejected

✅ Student Management (2 tests)
  ✓ Add student
  ✓ Search & filter

✅ Attendance (2 tests)
  ✓ Input attendance
  ✓ Mark all students

✅ Reports (2 tests)
  ✓ Generate report
  ✓ Export to CSV

✅ Security (1 test)
  ✓ Access control

Total: 10/10 PASSED ✅
```

---

## 👨‍💻 MANUAL TESTING (SYSTEM)

### Daftar Checklist Testing Manual

#### Testing Login

```bash
# Buka browser: http://localhost:8000

Test Case 1: Admin Login Valid
✓ Username: admin
✓ Password: admin123
✓ Klik Login
✓ Expected: Dashboard admin terbuka

Test Case 2: Teacher Login Valid
✓ Username: guru
✓ Password: guru123
✓ Klik Login
✓ Expected: Dashboard guru terbuka

Test Case 3: Invalid Login
✓ Username: invalid
✓ Password: wrong
✓ Klik Login
✓ Expected: Error message tampil
```

#### Testing Student Management

```
Test Case 4: Add Student
✓ Login sebagai admin
✓ Menu → Student Management
✓ Klik "Add Student"
✓ Isi form:
   - Name: Joko Setyawan
   - NIS: 12345
   - NISN: 0123456789
   - Date of Birth: 01/01/2008
   - Gender: Male
   - Class: 10-A
✓ Klik "Save"
✓ Expected: Student tersimpan, muncul di list

Test Case 5: Search Student
✓ Di halaman Student List
✓ Isi search: "Joko"
✓ Klik Search
✓ Expected: Hanya "Joko Setyawan" tampil

Test Case 6: Edit Student
✓ Klik tombol Edit di student Joko
✓ Ubah Name menjadi: "Joko Setyawan Updated"
✓ Klik "Save"
✓ Expected: Perubahan tersimpan

Test Case 7: Delete Student
✓ Klik tombol Delete di student
✓ Confirm deletion
✓ Expected: Student tidak tampil di list (soft delete)
```

#### Testing Attendance

```
Test Case 8: Input Attendance
✓ Login sebagai guru
✓ Menu → Attendance
✓ Pilih kelas dan jadwal
✓ Mark attendance:
   - 5 students: Hadir (Present)
   - 2 students: Sakit (Sick)
   - 1 student: Izin (Excuse)
✓ Klik "Submit"
✓ Expected: Attendance tersimpan

Test Case 9: View Attendance History
✓ Klik "Attendance History"
✓ Pilih date range
✓ Expected: Semua attendance history tampil
```

#### Testing Reports

```
Test Case 10: Generate Report
✓ Login sebagai admin
✓ Menu → Reports
✓ Pilih:
   - Start Date: 01/08/2024
   - End Date: 31/08/2024
   - Class: 10-A
✓ Klik "Generate"
✓ Expected: Report tampil dengan data

Test Case 11: Export Report
✓ Di halaman report
✓ Klik "Export to CSV"
✓ Expected: File CSV download
✓ Buka di Excel → verifikasi data
```

#### Testing Permissions

```
Test Case 12: Teacher Cannot Access Admin
✓ Login sebagai guru
✓ Coba akses URL: /admin/dashboard.php
✓ Expected: Access Denied / 403 Error

Test Case 13: Session Timeout
✓ Login sebagai admin
✓ Biarkan idle 30 menit (atau ganti timeout di config)
✓ Coba klik tombol
✓ Expected: Redirect ke login page
```

### Dokumentasi Hasil

Untuk setiap test case, catat:

```
Test Case ID: TC-001
Test Name: Admin Login Valid
Status: ✅ PASS / ❌ FAIL
Date: 10/08/2024
Tester: ASWAN
Notes: Login berhasil, dashboard terbuka normal
Screenshot: (attach if needed)
```

---

## 📊 RINGKAS HASIL TESTING

### Template Hasil Testing

Setelah menjalankan semua tests, isi tabel berikut:

```
Tanggal: __________
Tester: __________

| Testing Type | Total | Passed | Failed | Duration | Status |
|---|---|---|---|---|---|
| Unit Tests | 42 | _ | _ | _ | |
| Integration | 6 | _ | _ | _ | |
| API (Postman) | 20+ | _ | _ | _ | |
| Load (JMeter) | 2 | _ | _ | _ | |
| E2E (Cypress) | 10 | _ | _ | _ | |
| Manual | 13 | _ | _ | _ | |
| **TOTAL** | **93+** | _ | _ | _ | |

Overall Status: ✅ PASS / ❌ FAIL

Code Coverage: _______ % (Target: 70%)
Performance: _______ ms (Target: < 500ms)
```

---

## 🚨 TROUBLESHOOTING

### Problem: "Database connection error"

```
Solution:
1. Pastikan MySQL sudah start (XAMPP Control Panel)
2. Cek config/database.php
3. Import database: mysql -u root < database/database.sql
```

### Problem: "Cannot find ./vendor/bin/phpunit"

```
Solution:
1. Run: composer install
2. Verify: ls vendor/bin/ (harus ada phpunit)
```

### Problem: "Port 8000 already in use"

```
Solution:
1. Gunakan port lain: php -S localhost:8001
2. Atau kill process: lsof -i :8000 && kill -9 <PID>
```

### Problem: "Postman collection tests failed"

```
Solution:
1. Pastikan web server running (php -S localhost:8000)
2. Jalankan login request dulu (untuk generate session_token)
3. Cek environment: BASE_URL harus benar
4. Jalankan collection ulang
```

### Problem: "Cypress tests timeout"

```
Solution:
1. Tunggu web server fully loaded
2. Update cypress timeout di cypress.config.js:
   requestTimeout: 10000,
   defaultCommandTimeout: 5000
```

### Problem: "JMeter connection refused"

```
Solution:
1. Pastikan web server masih berjalan
2. Check URL: http://localhost:8000/MID SCABLE/admin/dashboard.php
3. Pastikan no spaces atau special chars di path
4. Verify dengan: curl http://localhost:8000/
```

---

## ✔️ CHECKLIST TESTING LENGKAP

### Pre-Testing
- [ ] Database imported dan verified
- [ ] Web server running (`php -S localhost:8000`)
- [ ] Composer dependencies installed
- [ ] NPM dependencies installed
- [ ] Postman installed/opened
- [ ] JMeter installed
- [ ] Cypress installed
- [ ] Browser updated (Chrome/Firefox)

### Execution
- [ ] Unit tests executed (42 tests) → Coverage: _____% ✅
- [ ] Integration tests executed (6 tests) ✅
- [ ] API tests executed (20+ tests) ✅
- [ ] Load tests executed (JMeter) ✅
- [ ] E2E tests executed (Cypress 10 tests) ✅
- [ ] Manual testing completed (13 test cases) ✅
- [ ] Defects documented (if any)
- [ ] All results captured

### Reporting
- [ ] Test summary filled
- [ ] Coverage report generated
- [ ] Performance metrics recorded
- [ ] Screenshots captured (if needed)
- [ ] Test results documented
- [ ] Ready for UAT sign-off

---

## 📞 KONTAK & SUPPORT

**Jika ada masalah:**
1. Cek troubleshooting section di atas
2. Baca dokumentasi lengkap di `03_Test_Scripts_and_Automation/Test_Execution_Guide.md`
3. Check file `02_Test_Plans_and_Reports/Test_Plan_and_Cases.md` untuk detail test cases

**Resources:**
- PHP Documentation: https://www.php.net/
- Composer: https://getcomposer.io/
- PHPUnit: https://phpunit.de/
- Postman Learning Center: https://learning.postman.com/
- JMeter Docs: https://jmeter.apache.org/
- Cypress Docs: https://docs.cypress.io/

---

## 📝 CATATAN PENTING

```
⚠️ JANGAN LUPA:
1. Web server harus selalu running saat testing
2. Database harus sudah di-import sebelum testing
3. Untuk Postman: login test harus jalan duluan
4. Coverage target minimum: 70%
5. Response time target: < 500ms
6. All tests should have 100% pass rate
7. Dokumentasi hasil testing WAJIB disimpan
```
