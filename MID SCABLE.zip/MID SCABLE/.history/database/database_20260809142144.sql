-- Sistem Informasi Sekolah dan Absensi
-- Database SQL

-- Hapus database jika sudah ada
DROP DATABASE IF EXISTS sistem_absensi_sekolah;

-- Buat database
CREATE DATABASE sistem_absensi_sekolah
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

-- Gunakan database
USE sistem_absensi_sekolah;

-- ====================================================
-- TABEL: teachers
-- ====================================================
CREATE TABLE teachers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nip VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('Laki-laki', 'Perempuan') NOT NULL,
    email VARCHAR(100),
    nomor_telepon VARCHAR(15),
    status ENUM('aktif', 'nonaktif', 'cuti', 'pensiun') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_nip (nip),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: users
-- ====================================================
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'guru') NOT NULL,
    teacher_id INT,
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: classes
-- ====================================================
CREATE TABLE classes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tingkat INT NOT NULL,
    nama_kelas VARCHAR(50) NOT NULL,
    wali_kelas_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (wali_kelas_id) REFERENCES teachers(id) ON DELETE SET NULL,
    UNIQUE KEY unique_kelas (tingkat, nama_kelas),
    INDEX idx_tingkat (tingkat)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: students
-- ====================================================
CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nis VARCHAR(20) NOT NULL UNIQUE,
    nisn VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    jenis_kelamin ENUM('Laki-laki', 'Perempuan') NOT NULL,
    tempat_lahir VARCHAR(50),
    tanggal_lahir DATE,
    alamat TEXT,
    nomor_telepon VARCHAR(15),
    class_id INT NOT NULL,
    status ENUM('aktif', 'pindah', 'lulus', 'keluar') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE,
    INDEX idx_nis (nis),
    INDEX idx_nisn (nisn),
    INDEX idx_class (class_id),
    INDEX idx_status (status),
    INDEX idx_nama (nama)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: subjects
-- ====================================================
CREATE TABLE subjects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    kode_mapel VARCHAR(20) NOT NULL UNIQUE,
    nama_mapel VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_kode (kode_mapel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: schedules
-- ====================================================
CREATE TABLE schedules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    teacher_id INT NOT NULL,
    subject_id INT NOT NULL,
    class_id INT NOT NULL,
    hari ENUM('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu') NOT NULL,
    jam_mulai TIME NOT NULL,
    jam_selesai TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE,
    INDEX idx_teacher (teacher_id),
    INDEX idx_class (class_id),
    INDEX idx_subject (subject_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: attendance_sessions
-- ====================================================
CREATE TABLE attendance_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    schedule_id INT NOT NULL,
    tanggal DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (schedule_id) REFERENCES schedules(id) ON DELETE CASCADE,
    UNIQUE KEY unique_session (schedule_id, tanggal),
    INDEX idx_schedule (schedule_id),
    INDEX idx_tanggal (tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- TABEL: attendance_details
-- ====================================================
CREATE TABLE attendance_details (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL,
    student_id INT NOT NULL,
    status ENUM('hadir', 'sakit', 'izin', 'alfa') NOT NULL,
    keterangan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES attendance_sessions(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE KEY unique_attendance (session_id, student_id),
    INDEX idx_session (session_id),
    INDEX idx_student (student_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================
-- DATA DEFAULT: Admin User
-- ====================================================
-- Password: admin123 (hash: $2y$10$YourHashedPasswordHere)
-- Untuk generate hash password, gunakan:
-- echo password_hash('admin123', PASSWORD_BCRYPT);
INSERT INTO users (username, email, password, role, status) VALUES
('admin', 'admin@sekolah.com', '$2y$10$Xvw2L6K8nZ9qH4jM3pL5Y.E8Rz5K2nL9pO7q6R5s4T3u2V1w0X', 'admin', 'aktif');

-- ====================================================
-- DATA DEFAULT: Mata Pelajaran
-- ====================================================
INSERT INTO subjects (kode_mapel, nama_mapel) VALUES
('MTK', 'Matematika'),
('BHS', 'Bahasa Indonesia'),
('IPA', 'Ilmu Pengetahuan Alam'),
('IPS', 'Ilmu Pengetahuan Sosial'),
('ENG', 'Bahasa Inggris'),
('OLH', 'Olahraga dan Kesehatan'),
('SEN', 'Seni Budaya'),
('PKN', 'Pendidikan Kewarganegaraan'),
('TIK', 'Teknologi Informasi dan Komunikasi');

-- ====================================================
-- DATA DEFAULT: Teacher/Guru
-- ====================================================
INSERT INTO teachers (nip, nama, jenis_kelamin, email, nomor_telepon, status) VALUES
('198501151005011234', 'Budi Santoso, S.Pd', 'Laki-laki', 'budi@sekolah.com', '08123456789', 'aktif'),
('198602201006021345', 'Siti Nurhaliza, S.Pd', 'Perempuan', 'siti@sekolah.com', '08129876543', 'aktif'),
('198703301007031456', 'Ahmad Syaiful, S.Pd', 'Laki-laki', 'ahmad@sekolah.com', '08121122334', 'aktif'),
('198804401008041567', 'Dewi Lestari, S.Pd', 'Perempuan', 'dewi@sekolah.com', '08125544332', 'aktif');

-- ====================================================
-- DATA DEFAULT: Classes
-- ====================================================
INSERT INTO classes (tingkat, nama_kelas, wali_kelas_id) VALUES
(7, 'A', 1),
(7, 'B', 2),
(8, 'A', 3),
(8, 'B', 4),
(9, 'A', 1),
(9, 'B', 2);

-- ====================================================
-- DATA DEFAULT: Students
-- ====================================================
INSERT INTO students (nis, nisn, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, nomor_telepon, class_id, status) VALUES
('0001', '1234567890001', 'Andi Wijaya', 'Laki-laki', 'Jakarta', '2009-05-15', 'Jl. Merdeka No. 1', '08151234567', 1, 'aktif'),
('0002', '1234567890002', 'Budi Hartono', 'Laki-laki', 'Bandung', '2009-06-20', 'Jl. Sudirman No. 2', '08152234567', 1, 'aktif'),
('0003', '1234567890003', 'Cindy Pratiwi', 'Perempuan', 'Bogor', '2009-07-25', 'Jl. Gatot Subroto No. 3', '08153234567', 1, 'aktif'),
('0004', '1234567890004', 'Danang Permana', 'Laki-laki', 'Jakarta', '2009-08-10', 'Jl. Ahmad Yani No. 4', '08154234567', 1, 'aktif'),
('0005', '1234567890005', 'Eka Sujana', 'Perempuan', 'Bekasi', '2009-09-05', 'Jl. Diponegoro No. 5', '08155234567', 2, 'aktif'),
('0006', '1234567890006', 'Fajar Rizkian', 'Laki-laki', 'Tangerang', '2009-10-12', 'Jl. Imam Bonjol No. 6', '08156234567', 2, 'aktif'),
('0007', '1234567890007', 'Gita Santoso', 'Perempuan', 'Jakarta', '2009-11-08', 'Jl. Matraman No. 7', '08157234567', 2, 'aktif'),
('0008', '1234567890008', 'Hendra Kusuma', 'Laki-laki', 'Depok', '2009-12-20', 'Jl. Raden Saleh No. 8', '08158234567', 2, 'aktif'),
('0009', '1234567890009', 'Intan Permata', 'Perempuan', 'Jakarta', '2008-05-15', 'Jl. Blora No. 9', '08159234567', 3, 'aktif'),
('0010', '1234567890010', 'Joko Setiawan', 'Laki-laki', 'Jakarta', '2008-06-20', 'Jl. Madiun No. 10', '08151234568', 3, 'aktif'),
('0011', '1234567890011', 'Karina Wijaya', 'Perempuan', 'Bekasi', '2008-07-25', 'Jl. Kelapa No. 11', '08152234568', 3, 'aktif'),
('0012', '1234567890012', 'Luthfi Rahman', 'Laki-laki', 'Jakarta', '2008-08-10', 'Jl. Barito No. 12', '08153234568', 3, 'aktif');

-- ====================================================
-- DATA DEFAULT: Schedules
-- ====================================================
INSERT INTO schedules (teacher_id, subject_id, class_id, hari, jam_mulai, jam_selesai) VALUES
(1, 1, 1, 'Senin', '07:00:00', '08:30:00'),
(1, 1, 1, 'Rabu', '09:00:00', '10:30:00'),
(2, 2, 1, 'Selasa', '08:00:00', '09:30:00'),
(2, 2, 1, 'Kamis', '10:00:00', '11:30:00'),
(3, 3, 2, 'Senin', '10:00:00', '11:30:00'),
(3, 3, 2, 'Jumat', '08:00:00', '09:30:00'),
(4, 4, 2, 'Selasa', '09:00:00', '10:30:00'),
(4, 4, 2, 'Rabu', '13:00:00', '14:30:00'),
(1, 5, 3, 'Senin', '12:00:00', '13:30:00'),
(2, 1, 3, 'Selasa', '10:00:00', '11:30:00');

-- ====================================================
-- DATA DEFAULT: User Guru
-- ====================================================
-- Password: guru123 (hash: $2y$10$...)
INSERT INTO users (username, email, password, role, teacher_id, status) VALUES
('budi', 'budi@sekolah.com', '$2y$10$Xvw2L6K8nZ9qH4jM3pL5Y.E8Rz5K2nL9pO7q6R5s4T3u2V1w0X', 'guru', 1, 'aktif'),
('siti', 'siti@sekolah.com', '$2y$10$Xvw2L6K8nZ9qH4jM3pL5Y.E8Rz5K2nL9pO7q6R5s4T3u2V1w0X', 'guru', 2, 'aktif'),
('ahmad', 'ahmad@sekolah.com', '$2y$10$Xvw2L6K8nZ9qH4jM3pL5Y.E8Rz5K2nL9pO7q6R5s4T3u2V1w0X', 'guru', 3, 'aktif'),
('dewi', 'dewi@sekolah.com', '$2y$10$Xvw2L6K8nZ9qH4jM3pL5Y.E8Rz5K2nL9pO7q6R5s4T3u2V1w0X', 'guru', 4, 'aktif');

-- ====================================================
-- INFO LOGIN DEFAULT
-- ====================================================
-- Admin:
--   Username: admin
--   Password: admin123
--
-- Guru:
--   Username: budi / siti / ahmad / dewi
--   Password: guru123
-- ====================================================
