<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_teacher();

$page_title = "Jadwal Mengajar Saya";
$teacher_id = $_SESSION['teacher_id'] ?? null;

if (!$teacher_id) {
    header("Location: ../../auth/logout.php");
    exit;
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_teacher.php';

// Ambil semua jadwal mengajar guru
$sql = "SELECT 
    sc.*, 
    sub.nama_mapel,
    sub.kode_mapel,
    c.nama_kelas,
    c.tingkat,
    COUNT(st.id) as jumlah_siswa
FROM schedules sc
INNER JOIN subjects sub ON sc.subject_id = sub.id
INNER JOIN classes c ON sc.class_id = c.id
LEFT JOIN students st ON c.id = st.class_id AND st.status = 'aktif'
WHERE sc.teacher_id = ?
GROUP BY sc.id
ORDER BY 
    CASE 
        WHEN sc.hari = 'Senin' THEN 1
        WHEN sc.hari = 'Selasa' THEN 2
        WHEN sc.hari = 'Rabu' THEN 3
        WHEN sc.hari = 'Kamis' THEN 4
        WHEN sc.hari = 'Jumat' THEN 5
        WHEN sc.hari = 'Sabtu' THEN 6
    END,
    sc.jam_mulai ASC";

$stmt = prepare_query($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$schedules = fetch_all($stmt->get_result());
?>

    <div class="container-fluid px-4">
        <!-- Display messages -->
        <?php display_message(); ?>
        
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-calendar-check page-header-icon"></i>
                Jadwal Mengajar Saya
            </h1>
        </div>

        <div class="page-content">
            <?php if (empty($schedules)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i>
                    Anda tidak memiliki jadwal mengajar.
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($schedules as $schedule): ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card h-100" style="border-left: 4px solid #667eea;">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo htmlspecialchars($schedule['nama_mapel']); ?>
                                    </h5>
                                    
                                    <div class="mb-3">
                                        <small class="text-muted d-block">
                                            <i class="bi bi-building"></i>
                                            Kelas <?php echo htmlspecialchars($schedule['tingkat']); ?> <?php echo htmlspecialchars($schedule['nama_kelas']); ?>
                                        </small>
                                        <small class="text-muted d-block">
                                            <i class="bi bi-calendar3"></i>
                                            <?php echo htmlspecialchars($schedule['hari']); ?>
                                        </small>
                                        <small class="text-muted d-block">
                                            <i class="bi bi-clock"></i>
                                            <?php echo $schedule['jam_mulai']; ?> - <?php echo $schedule['jam_selesai']; ?>
                                        </small>
                                        <small class="text-muted d-block">
                                            <i class="bi bi-people"></i>
                                            <?php echo $schedule['jumlah_siswa']; ?> Siswa
                                        </small>
                                    </div>

                                    <a href="input.php?schedule_id=<?php echo $schedule['id']; ?>" class="btn btn-primary btn-sm w-100">
                                        <i class="bi bi-pencil-square"></i> Input Absensi
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
