<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_teacher();

$page_title = "Riwayat Absensi";
$teacher_id = $_SESSION['teacher_id'] ?? null;

if (!$teacher_id) {
    header("Location: ../../auth/logout.php");
    exit;
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_teacher.php';

// Ambil riwayat absensi
$sql = "SELECT 
    asess.*, 
    sc.hari,
    sc.jam_mulai,
    sc.jam_selesai,
    sub.nama_mapel,
    c.nama_kelas,
    c.tingkat,
    COUNT(ad.id) as jumlah_siswa,
    SUM(CASE WHEN ad.status = 'hadir' THEN 1 ELSE 0 END) as hadir,
    SUM(CASE WHEN ad.status = 'sakit' THEN 1 ELSE 0 END) as sakit,
    SUM(CASE WHEN ad.status = 'izin' THEN 1 ELSE 0 END) as izin,
    SUM(CASE WHEN ad.status = 'alfa' THEN 1 ELSE 0 END) as alfa
FROM attendance_sessions asess
INNER JOIN schedules sc ON asess.schedule_id = sc.id
INNER JOIN subjects sub ON sc.subject_id = sub.id
INNER JOIN classes c ON sc.class_id = c.id
LEFT JOIN attendance_details ad ON asess.id = ad.session_id
WHERE sc.teacher_id = ?
GROUP BY asess.id
ORDER BY asess.tanggal DESC, sc.jam_mulai DESC";

$stmt = prepare_query($sql);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$history = fetch_all($stmt->get_result());
?>

    <div class="container-fluid px-4">
        <!-- Display messages -->
        <?php display_message(); ?>
        
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-clock-history page-header-icon"></i>
                Riwayat Absensi
            </h1>
        </div>

        <div class="page-content">
            <?php if (empty($history)): ?>
                <div class="alert alert-info">
                    <i class="bi bi-info-circle"></i>
                    Belum ada data absensi.
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($history as $item): ?>
                        <div class="col-md-6 col-lg-4 mb-4">
                            <div class="card h-100" style="border-top: 3px solid #667eea;">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <?php echo htmlspecialchars($item['nama_mapel']); ?>
                                    </h5>
                                    
                                    <div class="mb-3">
                                        <small class="text-muted d-block">
                                            <i class="bi bi-building"></i>
                                            Kelas <?php echo htmlspecialchars($item['tingkat'] . ' ' . $item['nama_kelas']); ?>
                                        </small>
                                        <small class="text-muted d-block">
                                            <i class="bi bi-calendar3"></i>
                                            <?php echo htmlspecialchars($item['hari'] . ', ' . date('d M Y', strtotime($item['tanggal']))); ?>
                                        </small>
                                        <small class="text-muted d-block">
                                            <i class="bi bi-clock"></i>
                                            <?php echo $item['jam_mulai']; ?> - <?php echo $item['jam_selesai']; ?>
                                        </small>
                                    </div>

                                    <!-- Statistik -->
                                    <div class="row text-center mb-3">
                                        <div class="col-6 col-sm-3">
                                            <span class="badge badge-hadir" style="display: block; margin-bottom: 3px;">
                                                <?php echo $item['hadir'] ?? 0; ?>
                                            </span>
                                            <small class="text-muted">Hadir</small>
                                        </div>
                                        <div class="col-6 col-sm-3">
                                            <span class="badge badge-sakit" style="display: block; margin-bottom: 3px;">
                                                <?php echo $item['sakit'] ?? 0; ?>
                                            </span>
                                            <small class="text-muted">Sakit</small>
                                        </div>
                                        <div class="col-6 col-sm-3">
                                            <span class="badge badge-izin" style="display: block; margin-bottom: 3px;">
                                                <?php echo $item['izin'] ?? 0; ?>
                                            </span>
                                            <small class="text-muted">Izin</small>
                                        </div>
                                        <div class="col-6 col-sm-3">
                                            <span class="badge badge-alfa" style="display: block; margin-bottom: 3px;">
                                                <?php echo $item['alfa'] ?? 0; ?>
                                            </span>
                                            <small class="text-muted">Alfa</small>
                                        </div>
                                    </div>

                                    <a href="input.php?schedule_id=<?php echo $item['schedule_id']; ?>&session_id=<?php echo $item['id']; ?>" 
                                       class="btn btn-sm btn-primary w-100">
                                        <i class="bi bi-eye"></i> Lihat Detail
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
