<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_teacher();

$page_title = "Input Absensi";
$teacher_id = $_SESSION['teacher_id'] ?? null;
$schedule_id = isset($_GET['schedule_id']) ? (int)$_GET['schedule_id'] : 0;

if (!$teacher_id || !$schedule_id) {
    header("Location: index.php");
    exit;
}

// Validasi bahwa schedule milik guru yang login
$sql_check = "SELECT * FROM schedules WHERE id = ? AND teacher_id = ?";
$stmt = prepare_query($sql_check);
$stmt->bind_param("ii", $schedule_id, $teacher_id);
$stmt->execute();
$schedule = $stmt->get_result()->fetch_assoc();

if (!$schedule) {
    $_SESSION['message'] = 'Jadwal tidak ditemukan atau bukan jadwal Anda!';
    $_SESSION['message_type'] = 'danger';
    header("Location: index.php");
    exit;
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_teacher.php';

// Ambil info jadwal lengkap
$sql_schedule = "SELECT 
    sc.*, 
    sub.nama_mapel,
    c.nama_kelas,
    c.tingkat
FROM schedules sc
INNER JOIN subjects sub ON sc.subject_id = sub.id
INNER JOIN classes c ON sc.class_id = c.id
WHERE sc.id = ?";

$stmt = prepare_query($sql_schedule);
$stmt->bind_param("i", $schedule_id);
$stmt->execute();
$schedule_full = $stmt->get_result()->fetch_assoc();

// Ambil daftar siswa kelas
$sql_students = "SELECT * FROM students 
WHERE class_id = ? AND status = 'aktif'
ORDER BY nama ASC";

$stmt = prepare_query($sql_students);
$stmt->bind_param("i", $schedule['class_id']);
$stmt->execute();
$students = fetch_all($stmt->get_result());

// Proses form submit
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = isset($_POST['tanggal']) ? sanitize($_POST['tanggal']) : date('Y-m-d');
    $attendance_data = isset($_POST['attendance']) ? $_POST['attendance'] : [];
    
    // Validasi tanggal
    if (empty($tanggal)) {
        $error = 'Tanggal harus diisi!';
    } else {
        // Cek apakah sudah ada session absensi untuk jadwal dan tanggal ini
        $sql_check_session = "SELECT id FROM attendance_sessions 
                            WHERE schedule_id = ? AND tanggal = ?";
        $stmt = prepare_query($sql_check_session);
        $stmt->bind_param("is", $schedule_id, $tanggal);
        $stmt->execute();
        $existing_session = $stmt->get_result()->fetch_assoc();
        
        if ($existing_session) {
            $session_id = $existing_session['id'];
        } else {
            // Buat session absensi baru
            $sql_insert_session = "INSERT INTO attendance_sessions (schedule_id, tanggal) VALUES (?, ?)";
            $stmt = prepare_query($sql_insert_session);
            $stmt->bind_param("is", $schedule_id, $tanggal);
            
            if (!$stmt->execute()) {
                $error = 'Gagal membuat session absensi: ' . $stmt->error;
            } else {
                $session_id = $stmt->insert_id;
            }
        }
        
        if (!$error) {
            // Proses attendance data
            $count_inserted = 0;
            $count_updated = 0;
            
            foreach ($attendance_data as $student_id => $data) {
                $student_id = (int)$student_id;
                $status = isset($data['status']) ? sanitize($data['status']) : '';
                $keterangan = isset($data['keterangan']) ? sanitize($data['keterangan']) : '';
                
                // Validasi status
                if (!in_array($status, ['hadir', 'sakit', 'izin', 'alfa'])) {
                    continue;
                }
                
                // Cek apakah sudah ada record
                $sql_check_detail = "SELECT id FROM attendance_details 
                                    WHERE session_id = ? AND student_id = ?";
                $stmt = prepare_query($sql_check_detail);
                $stmt->bind_param("ii", $session_id, $student_id);
                $stmt->execute();
                $existing_detail = $stmt->get_result()->fetch_assoc();
                
                if ($existing_detail) {
                    // Update
                    $sql_update = "UPDATE attendance_details 
                                  SET status = ?, keterangan = ? 
                                  WHERE session_id = ? AND student_id = ?";
                    $stmt = prepare_query($sql_update);
                    $stmt->bind_param("ssii", $status, $keterangan, $session_id, $student_id);
                    if ($stmt->execute()) {
                        $count_updated++;
                    }
                } else {
                    // Insert
                    $sql_insert = "INSERT INTO attendance_details (session_id, student_id, status, keterangan) 
                                  VALUES (?, ?, ?, ?)";
                    $stmt = prepare_query($sql_insert);
                    $stmt->bind_param("iiss", $session_id, $student_id, $status, $keterangan);
                    if ($stmt->execute()) {
                        $count_inserted++;
                    }
                }
            }
            
            $success = "Absensi berhasil disimpan! ($count_inserted ditambah, $count_updated diubah)";
        }
    }
}

// Ambil data absensi hari ini jika ada (untuk pre-fill form)
$tanggal_sekarang = date('Y-m-d');
$sql_today_attendance = "SELECT * FROM attendance_sessions 
                        WHERE schedule_id = ? AND tanggal = ?
                        ORDER BY created_at DESC LIMIT 1";
$stmt = prepare_query($sql_today_attendance);
$stmt->bind_param("is", $schedule_id, $tanggal_sekarang);
$stmt->execute();
$today_session = $stmt->get_result()->fetch_assoc();

$attendance_details = [];
if ($today_session) {
    $session_id = $today_session['id'];
    $sql_details = "SELECT * FROM attendance_details WHERE session_id = ?";
    $stmt = prepare_query($sql_details);
    $stmt->bind_param("i", $session_id);
    $stmt->execute();
    $attendance_details = fetch_all($stmt->get_result());
    
    // Convert to array indexed by student_id
    $temp = [];
    foreach ($attendance_details as $detail) {
        $temp[$detail['student_id']] = $detail;
    }
    $attendance_details = $temp;
}
?>

    <div class="container-fluid px-4">
        <!-- Display messages -->
        <?php display_message(); ?>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-pencil-square page-header-icon"></i>
                Input Absensi
            </h1>
        </div>

        <div class="page-content">
            <!-- Info Jadwal -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Mata Pelajaran:</strong> <?php echo htmlspecialchars($schedule_full['nama_mapel']); ?></p>
                            <p><strong>Kelas:</strong> <?php echo htmlspecialchars($schedule_full['tingkat'] . ' ' . $schedule_full['nama_kelas']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Hari:</strong> <?php echo htmlspecialchars($schedule_full['hari']); ?></p>
                            <p><strong>Jam:</strong> <?php echo $schedule_full['jam_mulai']; ?> - <?php echo $schedule_full['jam_selesai']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Form Absensi -->
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Daftar Siswa</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="tanggal" class="form-label">Tanggal</label>
                            <input type="date" class="form-control" id="tanggal" name="tanggal" 
                                   value="<?php echo date('Y-m-d'); ?>" required>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>NIS</th>
                                        <th>Nama Siswa</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($students)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-4">
                                                Tidak ada siswa di kelas ini
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($students as $index => $student): ?>
                                            <?php 
                                            $student_id = $student['id'];
                                            $existing = $attendance_details[$student_id] ?? null;
                                            ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td><?php echo htmlspecialchars($student['nis']); ?></td>
                                                <td><?php echo htmlspecialchars($student['nama']); ?></td>
                                                <td>
                                                    <select name="attendance[<?php echo $student_id; ?>][status]" class="form-select form-select-sm" required>
                                                        <option value="">-- Pilih --</option>
                                                        <option value="hadir" <?php echo ($existing && $existing['status'] === 'hadir') ? 'selected' : ''; ?>>Hadir</option>
                                                        <option value="sakit" <?php echo ($existing && $existing['status'] === 'sakit') ? 'selected' : ''; ?>>Sakit</option>
                                                        <option value="izin" <?php echo ($existing && $existing['status'] === 'izin') ? 'selected' : ''; ?>>Izin</option>
                                                        <option value="alfa" <?php echo ($existing && $existing['status'] === 'alfa') ? 'selected' : ''; ?>>Alfa</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <input type="text" name="attendance[<?php echo $student_id; ?>][keterangan]" class="form-control form-control-sm" 
                                                           placeholder="Opsional" value="<?php echo htmlspecialchars($existing['keterangan'] ?? ''); ?>">
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save"></i> Simpan Absensi
                            </button>
                            <a href="index.php" class="btn btn-secondary">
                                <i class="bi bi-arrow-left"></i> Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
