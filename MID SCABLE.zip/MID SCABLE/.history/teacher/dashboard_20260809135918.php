<?php
session_start();
require_once '../config/database.php';
require_once '../config/auth.php';

// Validasi role
require_teacher();

$page_title = "Dashboard Guru";
$teacher_id = $_SESSION['teacher_id'] ?? null;

if (!$teacher_id) {
    header("Location: ../auth/logout.php");
    exit;
}

include '../templates/header.php';
include '../templates/navbar.php';
include '../templates/sidebar_teacher.php';

// Ambil informasi guru
$teacher = query("SELECT * FROM teachers WHERE id = $teacher_id")->fetch_assoc();

// Jadwal mengajar hari ini
$hari_ini = date('Y-m-d');
$hari_ini_text = strtoupper(strftime('%A', strtotime($hari_ini)));
$hari_mapping = array(
    'SUNDAY' => 'Minggu',
    'MONDAY' => 'Senin',
    'TUESDAY' => 'Selasa',
    'WEDNESDAY' => 'Rabu',
    'THURSDAY' => 'Kamis',
    'FRIDAY' => 'Jumat',
    'SATURDAY' => 'Sabtu'
);
$hari_indo = $hari_mapping[$hari_ini_text] ?? 'Hari tidak dikenal';

$sql_today_schedules = "SELECT 
    sc.*, 
    sub.nama_mapel,
    c.nama_kelas
FROM schedules sc
INNER JOIN subjects sub ON sc.subject_id = sub.id
INNER JOIN classes c ON sc.class_id = c.id
WHERE sc.teacher_id = ? AND sc.hari = ?
ORDER BY sc.jam_mulai ASC";

$stmt = prepare_query($sql_today_schedules);
$stmt->bind_param("is", $teacher_id, $hari_indo);
$stmt->execute();
$today_schedules = fetch_all($stmt->get_result());

// Hitung total jadwal
$sql_all_schedules = "SELECT COUNT(*) as count FROM schedules WHERE teacher_id = ?";
$stmt = prepare_query($sql_all_schedules);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$total_schedules = $stmt->get_result()->fetch_assoc()['count'];

// Absensi terbaru guru
$sql_latest_attendance = "SELECT 
    ad.*, 
    s.nama as nama_siswa, 
    asess.tanggal,
    sc.hari,
    sub.nama_mapel,
    c.nama_kelas
FROM attendance_details ad
INNER JOIN attendance_sessions asess ON ad.session_id = asess.id
INNER JOIN schedules sc ON asess.schedule_id = sc.id
INNER JOIN students s ON ad.student_id = s.id
INNER JOIN subjects sub ON sc.subject_id = sub.id
INNER JOIN classes c ON sc.class_id = c.id
WHERE sc.teacher_id = ?
ORDER BY ad.created_at DESC
LIMIT 10";

$stmt = prepare_query($sql_latest_attendance);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$latest_attendance = fetch_all($stmt->get_result());
?>

    <div class="container-fluid px-4">
        <!-- Display messages -->
        <?php display_message(); ?>
        
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-speedometer2 page-header-icon"></i>
                Dashboard Guru
            </h1>
        </div>

        <!-- Statistics -->
        <div class="page-content">
            <div class="row mb-4">
                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #667eea;">
                            <i class="bi bi-person-badge"></i>
                        </div>
                        <div class="stat-card-number"><?php echo htmlspecialchars($teacher['nama'] ?? ''); ?></div>
                        <div class="stat-card-label">Nama Guru</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #28a745;">
                            <i class="bi bi-calendar-event"></i>
                        </div>
                        <div class="stat-card-number"><?php echo count($today_schedules); ?></div>
                        <div class="stat-card-label">Jadwal Hari Ini</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #ffc107;">
                            <i class="bi bi-book"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $total_schedules; ?></div>
                        <div class="stat-card-label">Total Jadwal</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #17a2b8;">
                            <i class="bi bi-info-circle"></i>
                        </div>
                        <div class="stat-card-number"><?php echo htmlspecialchars($teacher['nip'] ?? ''); ?></div>
                        <div class="stat-card-label">NIP</div>
                    </div>
                </div>
            </div>

            <!-- Row untuk dua card -->
            <div class="row">
                <!-- Jadwal Hari Ini -->
                <div class="col-md-6 col-lg-6 mb-4">
                    <div class="card">
                        <div class="card-header bg-light border-bottom">
                            <h5 class="mb-0">
                                <i class="bi bi-calendar-event" style="color: #667eea;"></i>
                                Jadwal Mengajar Hari Ini (<?php echo $hari_indo; ?>)
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($today_schedules)): ?>
                                <div class="text-center text-muted py-5">
                                    <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                                    <p class="mt-3">Anda tidak memiliki jadwal hari ini</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($today_schedules as $schedule): ?>
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($schedule['nama_mapel']); ?></h6>
                                                    <small class="text-muted"><?php echo htmlspecialchars($schedule['nama_kelas']); ?></small>
                                                </div>
                                                <div class="col-auto">
                                                    <span class="badge bg-primary">
                                                        <?php echo $schedule['jam_mulai']; ?> - <?php echo $schedule['jam_selesai']; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Absensi Terbaru -->
                <div class="col-md-6 col-lg-6 mb-4">
                    <div class="card">
                        <div class="card-header bg-light border-bottom">
                            <h5 class="mb-0">
                                <i class="bi bi-clock-history" style="color: #17a2b8;"></i>
                                Absensi Terbaru
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($latest_attendance)): ?>
                                <div class="text-center text-muted py-5">
                                    <i class="bi bi-inbox" style="font-size: 3rem;"></i>
                                    <p class="mt-3">Belum ada data absensi</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($latest_attendance as $att): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div style="flex: 1;">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($att['nama_siswa']); ?></h6>
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars($att['nama_mapel']); ?> | 
                                                        <?php echo htmlspecialchars($att['nama_kelas']); ?>
                                                    </small>
                                                </div>
                                                <span class="badge badge-<?php echo strtolower($att['status']); ?>">
                                                    <?php echo ucfirst($att['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tombol Mulai Absensi -->
            <div class="row mt-4">
                <div class="col-12">
                    <a href="attendance/input.php" class="btn btn-primary btn-lg w-100">
                        <i class="bi bi-pencil-square"></i> Mulai Input Absensi
                    </a>
                </div>
            </div>
        </div>
    </div>

<?php include '../templates/footer.php'; ?>
