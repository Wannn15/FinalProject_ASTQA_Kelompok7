<?php
/**
 * SYSTEM DIAGNOSTIC CHECK
 * URL: http://localhost/MID%20SCABLE/diagnostic.php
 * 
 * Script ini memeriksa semua aspek sistem untuk memastikan tidak ada error
 */

session_start();
require_once 'config/database.php';

$errors = [];
$warnings = [];
$success = [];

// =========================================
// 1. CEK KONEKSI DATABASE
// =========================================
echo "<h2>🔍 SYSTEM DIAGNOSTIC REPORT</h2>";
echo "<hr>";
echo "<h3>1️⃣ Database Connection</h3>";

if (!$mysqli->connect_error) {
    echo "✅ Database connected successfully<br>";
    echo "   Host: <code>localhost</code><br>";
    echo "   Database: <code>" . DB_NAME . "</code><br>";
    $success[] = "Database connection OK";
} else {
    echo "❌ Database connection FAILED<br>";
    echo "   Error: " . $mysqli->connect_error . "<br>";
    $errors[] = "Cannot connect to database";
}

// =========================================
// 2. CEK TABEL-TABEL
// =========================================
echo "<br><h3>2️⃣ Database Tables</h3>";

$required_tables = [
    'users' => 'User accounts',
    'teachers' => 'Teacher data',
    'classes' => 'Class data',
    'students' => 'Student data',
    'subjects' => 'Subject/Mata Pelajaran',
    'schedules' => 'Class schedules',
    'attendance_sessions' => 'Attendance sessions',
    'attendance_details' => 'Attendance records'
];

$table_status = [];
foreach ($required_tables as $table => $description) {
    $result = $mysqli->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "✅ <strong>$table</strong> - $description<br>";
        $table_status[$table] = true;
    } else {
        echo "❌ <strong>$table</strong> - MISSING<br>";
        $table_status[$table] = false;
        $errors[] = "Table '$table' is missing";
    }
}

// =========================================
// 3. CEK DATA DEFAULT
// =========================================
echo "<br><h3>3️⃣ Default Data</h3>";

// Cek admin user
$result = $mysqli->query("SELECT COUNT(*) as total FROM users WHERE role='admin'");
$row = $result->fetch_assoc();
if ($row['total'] > 0) {
    echo "✅ Admin user exists (<strong>" . $row['total'] . "</strong>)<br>";
    $success[] = "Admin user found";
} else {
    echo "⚠️ No admin user found<br>";
    $warnings[] = "No admin user in database";
}

// Cek guru users
$result = $mysqli->query("SELECT COUNT(*) as total FROM users WHERE role='guru'");
$row = $result->fetch_assoc();
if ($row['total'] > 0) {
    echo "✅ Teacher users exist (<strong>" . $row['total'] . "</strong>)<br>";
    $success[] = "Teacher users found";
} else {
    echo "⚠️ No teacher users found<br>";
    $warnings[] = "No teacher users in database";
}

// Cek guru data
$result = $mysqli->query("SELECT COUNT(*) as total FROM teachers");
$row = $result->fetch_assoc();
if ($row['total'] > 0) {
    echo "✅ Teachers data exists (<strong>" . $row['total'] . "</strong> teachers)<br>";
    $success[] = "Teachers data found";
} else {
    echo "⚠️ No teachers data found<br>";
    $warnings[] = "No teachers in database";
}

// Cek kelas data
$result = $mysqli->query("SELECT COUNT(*) as total FROM classes");
$row = $result->fetch_assoc();
if ($row['total'] > 0) {
    echo "✅ Classes data exists (<strong>" . $row['total'] . "</strong> classes)<br>";
    $success[] = "Classes data found";
} else {
    echo "⚠️ No classes data found<br>";
    $warnings[] = "No classes in database";
}

// Cek siswa data
$result = $mysqli->query("SELECT COUNT(*) as total FROM students");
$row = $result->fetch_assoc();
if ($row['total'] > 0) {
    echo "✅ Students data exists (<strong>" . $row['total'] . "</strong> students)<br>";
    $success[] = "Students data found";
} else {
    echo "⚠️ No students data found<br>";
    $warnings[] = "No students in database";
}

// Cek mata pelajaran
$result = $mysqli->query("SELECT COUNT(*) as total FROM subjects");
$row = $result->fetch_assoc();
if ($row['total'] > 0) {
    echo "✅ Subjects data exists (<strong>" . $row['total'] . "</strong> subjects)<br>";
    $success[] = "Subjects data found";
} else {
    echo "⚠️ No subjects data found<br>";
    $warnings[] = "No subjects in database";
}

// =========================================
// 4. CEK FILE-FILE KRITIS
// =========================================
echo "<br><h3>4️⃣ Critical Files</h3>";

$critical_files = [
    'config/database.php' => 'Database configuration',
    'config/auth.php' => 'Authentication helper',
    'auth/login.php' => 'Login page',
    'auth/logout.php' => 'Logout page',
    'auth/process_login.php' => 'Login processor',
    'admin/dashboard.php' => 'Admin dashboard',
    'teacher/dashboard.php' => 'Teacher dashboard',
    'templates/header.php' => 'Header template',
    'templates/navbar.php' => 'Navbar template',
    'templates/sidebar_admin.php' => 'Admin sidebar',
    'templates/sidebar_teacher.php' => 'Teacher sidebar'
];

$base_path = dirname(__FILE__);
foreach ($critical_files as $file => $description) {
    $full_path = $base_path . '/' . $file;
    if (file_exists($full_path)) {
        echo "✅ <code>$file</code> - $description<br>";
        $success[] = "File '$file' exists";
    } else {
        echo "❌ <code>$file</code> - MISSING<br>";
        $errors[] = "Critical file '$file' is missing";
    }
}

// =========================================
// 5. CEK FOREIGN KEY CONSTRAINTS
// =========================================
echo "<br><h3>5️⃣ Database Constraints</h3>";

$constraints = [
    'users.teacher_id -> teachers.id' => "SELECT COUNT(*) as total FROM users WHERE teacher_id IS NOT NULL AND teacher_id NOT IN (SELECT id FROM teachers)",
    'students.class_id -> classes.id' => "SELECT COUNT(*) as total FROM students WHERE class_id NOT IN (SELECT id FROM classes)",
    'schedules.teacher_id -> teachers.id' => "SELECT COUNT(*) as total FROM schedules WHERE teacher_id NOT IN (SELECT id FROM teachers)",
    'schedules.class_id -> classes.id' => "SELECT COUNT(*) as total FROM schedules WHERE class_id NOT IN (SELECT id FROM classes)",
    'schedules.subject_id -> subjects.id' => "SELECT COUNT(*) as total FROM schedules WHERE subject_id NOT IN (SELECT id FROM subjects)"
];

foreach ($constraints as $constraint => $sql) {
    $result = $mysqli->query($sql);
    if ($result) {
        $row = $result->fetch_assoc();
        if ($row['total'] == 0) {
            echo "✅ Constraint <code>$constraint</code> - OK<br>";
        } else {
            echo "⚠️ Constraint <code>$constraint</code> - <strong>" . $row['total'] . "</strong> violations<br>";
            $warnings[] = "Constraint violation: $constraint";
        }
    }
}

// =========================================
// 6. CEK PHP FUNCTIONS
// =========================================
echo "<br><h3>6️⃣ PHP Functions & Extensions</h3>";

$extensions = ['mysqli', 'json', 'session', 'hash'];
foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ Extension <code>$ext</code> - loaded<br>";
    } else {
        echo "❌ Extension <code>$ext</code> - NOT loaded<br>";
        $errors[] = "PHP extension '$ext' not loaded";
    }
}

// =========================================
// 7. CEK PERMISSION & CONFIG
// =========================================
echo "<br><h3>7️⃣ Configuration</h3>";

if (defined('DB_HOST') && defined('DB_USER') && defined('DB_NAME')) {
    echo "✅ Database constants defined<br>";
    echo "   DB_HOST: <code>" . DB_HOST . "</code><br>";
    echo "   DB_NAME: <code>" . DB_NAME . "</code><br>";
    echo "   BASE_PATH: <code>" . BASE_PATH . "</code><br>";
    $success[] = "Configuration OK";
} else {
    echo "❌ Database constants NOT defined<br>";
    $errors[] = "Database constants not properly defined";
}

// =========================================
// 8. SUMMARY
// =========================================
echo "<br><hr>";
echo "<h3>📊 SUMMARY REPORT</h3>";

echo "<p><strong>✅ Success:</strong> " . count($success) . " checks passed</p>";
echo "<p><strong>⚠️ Warnings:</strong> " . count($warnings) . " warnings</p>";
echo "<p><strong>❌ Errors:</strong> " . count($errors) . " errors</p>";

if (count($errors) == 0 && count($warnings) == 0) {
    echo "<div style='padding: 15px; background: #d4edda; border: 1px solid #c3e6cb; border-radius: 5px; color: #155724;'>";
    echo "<strong>✨ ALL SYSTEMS OPERATIONAL!</strong><br>";
    echo "Program berjalan lancar tanpa error. Anda siap menggunakan sistem.";
    echo "</div>";
} elseif (count($errors) == 0) {
    echo "<div style='padding: 15px; background: #fff3cd; border: 1px solid #ffeeba; border-radius: 5px; color: #856404;'>";
    echo "<strong>⚠️ SYSTEM OPERATIONAL WITH WARNINGS</strong><br>";
    echo "Sistem masih bisa berjalan, tapi ada beberapa peringatan yang perlu diperhatikan.";
    echo "</div>";
} else {
    echo "<div style='padding: 15px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 5px; color: #721c24;'>";
    echo "<strong>❌ SYSTEM HAS CRITICAL ERRORS</strong><br>";
    echo "Ada error yang perlu diperbaiki sebelum sistem dapat digunakan.";
    echo "</div>";
}

echo "<br>";
echo "<p style='margin-top: 20px; padding: 10px; background: #f0f0f0; border-radius: 5px;'>";
echo "📝 <strong>Diagnostic Date:</strong> " . date('Y-m-d H:i:s') . "<br>";
echo "📝 <strong>PHP Version:</strong> " . phpversion() . "<br>";
echo "📝 <strong>Server Software:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "<br>";
echo "</p>";

echo "<hr>";
echo "<p style='text-align: center; margin-top: 20px;'>";
echo "<a href='" . BASE_PATH . "/auth/login.php' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>👉 Go to Login</a> | ";
echo "<a href='" . BASE_PATH . "/admin/dashboard.php' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px;'>📊 Go to Dashboard</a>";
echo "</p>";
?>
