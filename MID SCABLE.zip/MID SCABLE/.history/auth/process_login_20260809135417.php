<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

// Ambil input
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Validasi input
if (empty($username) || empty($password)) {
    $_SESSION['message'] = 'Username dan password harus diisi!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

// Escape input untuk keamanan
$username = escape_string($username);

// Query mencari user berdasarkan username atau email
$sql = "SELECT * FROM users WHERE username = ? OR email = ?";
$stmt = prepare_query($sql);
$stmt->bind_param("ss", $username, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['message'] = 'Username atau password salah!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();

// Verifikasi password
if (!password_verify($password, $user['password'])) {
    $_SESSION['message'] = 'Username atau password salah!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

// Periksa status user
if ($user['status'] !== 'aktif') {
    $_SESSION['message'] = 'Akun Anda tidak aktif. Hubungi administrator!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

// Set session
$_SESSION['id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['email'] = $user['email'];
$_SESSION['role'] = $user['role'];

// Jika user adalah guru, simpan teacher_id juga
if ($user['role'] === 'guru' && $user['teacher_id']) {
    $_SESSION['teacher_id'] = $user['teacher_id'];
}

// Redirect berdasarkan role
if ($user['role'] === 'admin') {
    $_SESSION['message'] = 'Selamat datang, Admin!';
    $_SESSION['message_type'] = 'success';
    header("Location: ../admin/dashboard.php");
} elseif ($user['role'] === 'guru') {
    $_SESSION['message'] = 'Selamat datang, Guru!';
    $_SESSION['message_type'] = 'success';
    header("Location: ../teacher/dashboard.php");
} else {
    $_SESSION['message'] = 'Role tidak dikenali!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
}

exit;
