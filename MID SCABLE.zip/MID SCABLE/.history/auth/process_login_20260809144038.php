<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

// Ambil input
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Validasi input
if (empty($email) || empty($password)) {
    $_SESSION['message'] = 'Email dan password harus diisi!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

// Escape input untuk keamanan
$email = escape_string($email);

// Query mencari user berdasarkan email
$sql = "SELECT * FROM users WHERE email = ?";
$stmt = prepare_query($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['message'] = 'Email atau password salah!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

$user = $result->fetch_assoc();

// Verifikasi password
if (!password_verify($password, $user['password'])) {
    $_SESSION['message'] = 'Username atau password salah!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

// Periksa status user
if ($user['status'] !== 'aktif') {
    $_SESSION['message'] = 'Akun Anda tidak aktif. Hubungi administrator!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
    exit;
}

// Set session
$_SESSION['id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['email'] = $user['email'];
$_SESSION['role'] = $user['role'];

// Jika user adalah guru, simpan teacher_id juga
if ($user['role'] === 'guru' && $user['teacher_id']) {
    $_SESSION['teacher_id'] = $user['teacher_id'];
}

// Redirect berdasarkan role
if ($user['role'] === 'admin') {
    $_SESSION['message'] = 'Selamat datang, Admin!';
    $_SESSION['message_type'] = 'success';
    header("Location: ../admin/dashboard.php");
} elseif ($user['role'] === 'guru') {
    $_SESSION['message'] = 'Selamat datang, Guru!';
    $_SESSION['message_type'] = 'success';
    header("Location: ../teacher/dashboard.php");
} else {
    $_SESSION['message'] = 'Role tidak dikenali!';
    $_SESSION['message_type'] = 'danger';
    header("Location: login.php");
}

exit;
