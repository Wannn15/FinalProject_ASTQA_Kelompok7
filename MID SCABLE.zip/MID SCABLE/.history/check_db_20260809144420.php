<?php
/**
 * Script Verifikasi Database
 * URL: http://localhost/MID%20SCABLE/check_db.php
 */

require_once 'config/database.php';

echo "<h2>🔍 Verifikasi Database</h2><hr>";

// Cek koneksi
echo "<h3>1️⃣ Status Koneksi</h3>";
if (!$mysqli->connect_error) {
    echo "✅ Database terkoneksi dengan baik<br>";
    echo "   Database: <code>" . DB_NAME . "</code><br>";
    echo "   Host: <code>" . DB_HOST . "</code><br><br>";
} else {
    echo "❌ Database TIDAK terkoneksi: " . $mysqli->connect_error . "<br><br>";
    exit;
}

// Cek tabel users
echo "<h3>2️⃣ Tabel Users</h3>";
$result = $mysqli->query("SELECT COUNT(*) as total FROM users");
$row = $result->fetch_assoc();
echo "Total user: <code>" . $row['total'] . "</code> (seharusnya 5)<br><br>";

// Tampilkan semua users
echo "<h3>3️⃣ Daftar User</h3>";
echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%; margin: 10px 0;'>";
echo "<tr style='background: #f0f0f0;'><th>ID</th><th>Email</th><th>Role</th><th>Status</th><th>Password Hash</th></tr>";

$result = $mysqli->query("SELECT id, email, role, status, password FROM users ORDER BY id");
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td><strong>" . $row['email'] . "</strong></td>";
    echo "<td>" . $row['role'] . "</td>";
    echo "<td>" . $row['status'] . "</td>";
    echo "<td><small>" . substr($row['password'], 0, 30) . "...</small></td>";
    echo "</tr>";
}
echo "</table><br>";

// Cek tabel teachers
echo "<h3>4️⃣ Tabel Teachers</h3>";
$result = $mysqli->query("SELECT COUNT(*) as total FROM teachers");
$row = $result->fetch_assoc();
echo "Total guru: <code>" . $row['total'] . "</code> (seharusnya 4)<br><br>";

echo "<hr>";
echo "<p>✨ Database tampak OK! Jalankan <code>reset_password.php</code> untuk fix password hash.</p>";
echo "<p><a href='reset_password.php' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>👉 Reset Password Sekarang</a></p>";
?>
