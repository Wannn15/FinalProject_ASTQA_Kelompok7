<?php
/**
 * Debug Login Error
 * URL: http://localhost/MID%20SCABLE/debug_login.php
 */

echo "<h2>🔍 Debug Login System</h2>";
echo "<hr>";

// Test 1: Check database connection
echo "<h3>1️⃣ Database Connection</h3>";
require_once 'config/database.php';

if (!$mysqli->connect_error) {
    echo "✅ Database connected<br>";
} else {
    echo "❌ Database error: " . $mysqli->connect_error . "<br>";
}

// Test 2: Check if admin user exists
echo "<h3>2️⃣ Admin User</h3>";
$result = $mysqli->query("SELECT id, email, role, password FROM users WHERE email='admin@sekolah.com' LIMIT 1");
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "✅ Admin user found<br>";
    echo "   ID: " . $user['id'] . "<br>";
    echo "   Email: " . $user['email'] . "<br>";
    echo "   Role: " . $user['role'] . "<br>";
    echo "   Password Hash: " . substr($user['password'], 0, 30) . "...<br>";
    
    // Test password verification
    echo "<h3>3️⃣ Password Verification</h3>";
    $test_password = 'admin123';
    if (password_verify($test_password, $user['password'])) {
        echo "✅ Password 'admin123' is CORRECT<br>";
    } else {
        echo "❌ Password 'admin123' is INCORRECT<br>";
        echo "   This is the problem! Password hash doesn't match.<br>";
        echo "   <strong>Solution: Run reset_password.php</strong>";
    }
} else {
    echo "❌ Admin user NOT found<br>";
}

// Test 3: Check get_url function
echo "<h3>4️⃣ Helper Functions</h3>";
if (function_exists('get_url')) {
    echo "✅ get_url() function exists<br>";
    echo "   BASE_PATH: " . BASE_PATH . "<br>";
    echo "   get_url('/admin/dashboard.php'): " . get_url('/admin/dashboard.php') . "<br>";
} else {
    echo "❌ get_url() function NOT found<br>";
}

if (function_exists('is_current_page')) {
    echo "✅ is_current_page() function exists<br>";
} else {
    echo "❌ is_current_page() function NOT found<br>";
}

// Test 4: Check PHP version
echo "<h3>5️⃣ PHP Info</h3>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Extensions: ";
$extensions = ['mysqli', 'json', 'session', 'hash'];
foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "✅ $ext ";
    } else {
        echo "❌ $ext ";
    }
}

echo "<hr>";
echo "<p><a href='" . BASE_PATH . "/auth/login.php'>Back to Login</a> | ";
echo "<a href='" . BASE_PATH . "/reset_password.php'>Reset Password</a></p>";
?>