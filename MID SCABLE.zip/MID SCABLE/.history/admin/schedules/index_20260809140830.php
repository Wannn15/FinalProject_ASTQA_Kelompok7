<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Data Jadwal";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

$schedules = fetch_all(query("SELECT s.*, t.nama as nama_guru, sub.nama_mapel, c.nama_kelas, c.tingkat FROM schedules s INNER JOIN teachers t ON s.teacher_id = t.id INNER JOIN subjects sub ON s.subject_id = sub.id INNER JOIN classes c ON s.class_id = c.id ORDER BY t.nama ASC, s.hari ASC, s.jam_mulai ASC"));
?>

    <div class="container-fluid px-4">
        <?php display_message(); ?>
        
        <div class="page-header">
            <h1>
                <i class="bi bi-calendar-event page-header-icon"></i>
                Data Jadwal
            </h1>
        </div>

        <div class="page-content">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Jadwal</h5>
                    <a href="tambah.php" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle"></i> Tambah Jadwal
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Guru</th>
                                    <th>Mata Pelajaran</th>
                                    <th>Kelas</th>
                                    <th>Hari</th>
                                    <th>Jam</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($schedules)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">Tidak ada data jadwal</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($schedules as $index => $schedule): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($schedule['nama_guru']); ?></td>
                                            <td><?php echo htmlspecialchars($schedule['nama_mapel']); ?></td>
                                            <td><?php echo $schedule['tingkat'] . ' ' . htmlspecialchars($schedule['nama_kelas']); ?></td>
                                            <td><?php echo htmlspecialchars($schedule['hari']); ?></td>
                                            <td><?php echo $schedule['jam_mulai'] . ' - ' . $schedule['jam_selesai']; ?></td>
                                            <td>
                                                <a href="edit.php?id=<?php echo $schedule['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="hapus.php?id=<?php echo $schedule['id']; ?>" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
