<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Tambah Jadwal";

$teachers = fetch_all(query("SELECT * FROM teachers WHERE status = 'aktif' ORDER BY nama ASC"));
$subjects = fetch_all(query("SELECT * FROM subjects ORDER BY nama_mapel ASC"));
$classes = fetch_all(query("SELECT * FROM classes ORDER BY tingkat ASC, nama_kelas ASC"));

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacher_id = (int)($_POST['teacher_id'] ?? 0);
    $subject_id = (int)($_POST['subject_id'] ?? 0);
    $class_id = (int)($_POST['class_id'] ?? 0);
    $hari = sanitize($_POST['hari'] ?? '');
    $jam_mulai = sanitize($_POST['jam_mulai'] ?? '');
    $jam_selesai = sanitize($_POST['jam_selesai'] ?? '');

    if ($teacher_id <= 0 || $subject_id <= 0 || $class_id <= 0 || empty($hari) || empty($jam_mulai) || empty($jam_selesai)) {
        $error = 'Semua field harus diisi!';
    } else {
        $sql = "INSERT INTO schedules (teacher_id, subject_id, class_id, hari, jam_mulai, jam_selesai) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = prepare_query($sql);
        $stmt->bind_param("iiisss", $teacher_id, $subject_id, $class_id, $hari, $jam_mulai, $jam_selesai);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Jadwal berhasil ditambahkan!';
            $_SESSION['message_type'] = 'success';
            header("Location: index.php");
            exit;
        } else {
            $error = 'Gagal menambahkan jadwal!';
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-plus-circle page-header-icon"></i>
                Tambah Jadwal
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Tambah Jadwal</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Guru</label>
                                    <select class="form-select" name="teacher_id" required>
                                        <option value="">-- Pilih Guru --</option>
                                        <?php foreach ($teachers as $teacher): ?>
                                            <option value="<?php echo $teacher['id']; ?>">
                                                <?php echo htmlspecialchars($teacher['nama']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Mata Pelajaran</label>
                                    <select class="form-select" name="subject_id" required>
                                        <option value="">-- Pilih Mapel --</option>
                                        <?php foreach ($subjects as $subject): ?>
                                            <option value="<?php echo $subject['id']; ?>">
                                                <?php echo htmlspecialchars($subject['nama_mapel']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Kelas</label>
                                    <select class="form-select" name="class_id" required>
                                        <option value="">-- Pilih Kelas --</option>
                                        <?php foreach ($classes as $class): ?>
                                            <option value="<?php echo $class['id']; ?>">
                                                Kelas <?php echo $class['tingkat'] . ' ' . htmlspecialchars($class['nama_kelas']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Hari</label>
                                    <select class="form-select" name="hari" required>
                                        <option value="">-- Pilih Hari --</option>
                                        <option value="Senin">Senin</option>
                                        <option value="Selasa">Selasa</option>
                                        <option value="Rabu">Rabu</option>
                                        <option value="Kamis">Kamis</option>
                                        <option value="Jumat">Jumat</option>
                                        <option value="Sabtu">Sabtu</option>
                                    </select>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Jam Mulai</label>
                                        <input type="time" class="form-control" name="jam_mulai" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Jam Selesai</label>
                                        <input type="time" class="form-control" name="jam_selesai" required>
                                    </div>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
