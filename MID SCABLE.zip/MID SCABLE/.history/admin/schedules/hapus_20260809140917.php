<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$schedule_id = (int)($_GET['id'] ?? 0);

if (!$schedule_id) {
    header("Location: index.php");
    exit;
}

$sql_delete = "DELETE FROM schedules WHERE id = ?";
$stmt = prepare_query($sql_delete);
$stmt->bind_param("i", $schedule_id);

if ($stmt->execute()) {
    $_SESSION['message'] = 'Jadwal berhasil dihapus!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Gagal menghapus jadwal!';
    $_SESSION['message_type'] = 'danger';
}

header("Location: index.php");
exit;
