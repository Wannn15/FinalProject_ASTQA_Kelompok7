<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Detail Siswa";
$student_id = (int)($_GET['id'] ?? 0);
$student = query("SELECT s.*, c.nama_kelas, c.tingkat FROM students s INNER JOIN classes c ON s.class_id = c.id WHERE s.id = $student_id")->fetch_assoc();

if (!$student) {
    header("Location: index.php");
    exit;
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-person page-header-icon"></i>
                Detail Siswa
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0"><?php echo htmlspecialchars($student['nama']); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p><strong>NIS:</strong> <?php echo htmlspecialchars($student['nis']); ?></p>
                                    <p><strong>NISN:</strong> <?php echo htmlspecialchars($student['nisn']); ?></p>
                                    <p><strong>Jenis Kelamin:</strong> <?php echo htmlspecialchars($student['jenis_kelamin']); ?></p>
                                    <p><strong>Tempat Lahir:</strong> <?php echo htmlspecialchars($student['tempat_lahir'] ?? '-'); ?></p>
                                    <p><strong>Tanggal Lahir:</strong> <?php echo $student['tanggal_lahir'] ? date('d M Y', strtotime($student['tanggal_lahir'])) : '-'; ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Kelas:</strong> <?php echo $student['tingkat'] . ' ' . htmlspecialchars($student['nama_kelas']); ?></p>
                                    <p><strong>Nomor Telepon:</strong> <?php echo htmlspecialchars($student['nomor_telepon'] ?? '-'); ?></p>
                                    <p><strong>Status:</strong> <span class="badge bg-<?php echo $student['status'] === 'aktif' ? 'success' : 'warning'; ?>"><?php echo ucfirst($student['status']); ?></span></p>
                                    <p><strong>Terdaftar:</strong> <?php echo date('d M Y', strtotime($student['created_at'])); ?></p>
                                </div>
                            </div>
                            <p><strong>Alamat:</strong></p>
                            <p><?php echo htmlspecialchars($student['alamat'] ?? '-'); ?></p>

                            <div class="d-flex gap-2 mt-4">
                                <a href="edit.php?id=<?php echo $student['id']; ?>" class="btn btn-warning">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="bi bi-arrow-left"></i> Kembali
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
