<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$student_id = (int)($_GET['id'] ?? 0);

if (!$student_id) {
    header("Location: index.php");
    exit;
}

$sql_delete = "DELETE FROM students WHERE id = ?";
$stmt = prepare_query($sql_delete);
$stmt->bind_param("i", $student_id);

if ($stmt->execute()) {
    $_SESSION['message'] = 'Siswa berhasil dihapus!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Gagal menghapus siswa!';
    $_SESSION['message_type'] = 'danger';
}

header("Location: index.php");
exit;
