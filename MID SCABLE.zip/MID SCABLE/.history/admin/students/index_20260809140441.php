<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Data Siswa";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

// Pencarian dan filter
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$filter_class = isset($_GET['class']) ? (int)$_GET['class'] : 0;
$filter_status = isset($_GET['status']) ? sanitize($_GET['status']) : '';

// Query dasar
$sql = "SELECT s.*, c.nama_kelas, c.tingkat FROM students s 
        INNER JOIN classes c ON s.class_id = c.id WHERE 1=1";

// Tambah filter search
if (!empty($search)) {
    $search_escaped = escape_string($search);
    $sql .= " AND (s.nama LIKE '%$search_escaped%' OR s.nis LIKE '%$search_escaped%' OR s.nisn LIKE '%$search_escaped%')";
}

// Tambah filter class
if ($filter_class > 0) {
    $sql .= " AND s.class_id = $filter_class";
}

// Tambah filter status
if (!empty($filter_status)) {
    $filter_status_escaped = escape_string($filter_status);
    $sql .= " AND s.status = '$filter_status_escaped'";
}

$sql .= " ORDER BY s.nama ASC";

$students = fetch_all(query($sql));
$classes = fetch_all(query("SELECT * FROM classes ORDER BY tingkat ASC, nama_kelas ASC"));
?>

    <div class="container-fluid px-4">
        <?php display_message(); ?>
        
        <div class="page-header">
            <h1>
                <i class="bi bi-people page-header-icon"></i>
                Data Siswa
            </h1>
        </div>

        <div class="page-content">
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="search" placeholder="Cari nama/NIS/NISN" 
                                   value="<?php echo htmlspecialchars($search); ?>">
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" name="class">
                                <option value="">-- Semua Kelas --</option>
                                <?php foreach ($classes as $cls): ?>
                                    <option value="<?php echo $cls['id']; ?>" <?php echo $filter_class == $cls['id'] ? 'selected' : ''; ?>>
                                        Kelas <?php echo $cls['tingkat'] . ' ' . $cls['nama_kelas']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" name="status">
                                <option value="">-- Semua Status --</option>
                                <option value="aktif" <?php echo $filter_status === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                <option value="pindah" <?php echo $filter_status === 'pindah' ? 'selected' : ''; ?>>Pindah</option>
                                <option value="lulus" <?php echo $filter_status === 'lulus' ? 'selected' : ''; ?>>Lulus</option>
                                <option value="keluar" <?php echo $filter_status === 'keluar' ? 'selected' : ''; ?>>Keluar</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-search"></i> Cari
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Siswa</h5>
                    <div>
                        <a href="tambah.php" class="btn btn-primary btn-sm">
                            <i class="bi bi-plus-circle"></i> Tambah Siswa
                        </a>
                        <a href="export.php" class="btn btn-success btn-sm">
                            <i class="bi bi-download"></i> Export
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIS</th>
                                    <th>Nama</th>
                                    <th>Kelas</th>
                                    <th>L/P</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($students)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">Tidak ada data siswa</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($students as $index => $student): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($student['nis']); ?></td>
                                            <td><?php echo htmlspecialchars($student['nama']); ?></td>
                                            <td><?php echo $student['tingkat'] . ' ' . htmlspecialchars($student['nama_kelas']); ?></td>
                                            <td><?php echo $student['jenis_kelamin'] === 'Laki-laki' ? 'L' : 'P'; ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $student['status'] === 'aktif' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($student['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="detail.php?id=<?php echo $student['id']; ?>" class="btn btn-info btn-sm">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="edit.php?id=<?php echo $student['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="hapus.php?id=<?php echo $student['id']; ?>" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
