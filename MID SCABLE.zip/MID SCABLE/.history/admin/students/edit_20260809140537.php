<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Edit Siswa";
$student_id = (int)($_GET['id'] ?? 0);
$student = query("SELECT * FROM students WHERE id = $student_id")->fetch_assoc();

if (!$student) {
    header("Location: index.php");
    exit;
}

$classes = fetch_all(query("SELECT * FROM classes ORDER BY tingkat ASC, nama_kelas ASC"));
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = sanitize($_POST['nama'] ?? '');
    $jenis_kelamin = sanitize($_POST['jenis_kelamin'] ?? '');
    $tempat_lahir = sanitize($_POST['tempat_lahir'] ?? '');
    $tanggal_lahir = sanitize($_POST['tanggal_lahir'] ?? '');
    $alamat = sanitize($_POST['alamat'] ?? '');
    $nomor_telepon = sanitize($_POST['nomor_telepon'] ?? '');
    $class_id = (int)($_POST['class_id'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'aktif');

    if (empty($nama) || empty($jenis_kelamin) || $class_id <= 0) {
        $error = 'Field wajib harus diisi!';
    } else {
        $sql = "UPDATE students SET nama=?, jenis_kelamin=?, tempat_lahir=?, tanggal_lahir=?, alamat=?, nomor_telepon=?, class_id=?, status=? WHERE id=?";
        $stmt = prepare_query($sql);
        $stmt->bind_param("sssssssii", $nama, $jenis_kelamin, $tempat_lahir, $tanggal_lahir, $alamat, $nomor_telepon, $class_id, $status, $student_id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Siswa berhasil diperbarui!';
            $_SESSION['message_type'] = 'success';
            header("Location: index.php");
            exit;
        } else {
            $error = 'Gagal memperbarui siswa!';
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-pencil page-header-icon"></i>
                Edit Siswa
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Edit Siswa</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">NIS</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($student['nis']); ?>" disabled>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">NISN</label>
                                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($student['nisn']); ?>" disabled>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama Siswa</label>
                                    <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($student['nama']); ?>" required>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Jenis Kelamin</label>
                                        <select class="form-select" name="jenis_kelamin" required>
                                            <option value="Laki-laki" <?php echo $student['jenis_kelamin'] === 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
                                            <option value="Perempuan" <?php echo $student['jenis_kelamin'] === 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Kelas</label>
                                        <select class="form-select" name="class_id" required>
                                            <?php foreach ($classes as $cls): ?>
                                                <option value="<?php echo $cls['id']; ?>" <?php echo $student['class_id'] == $cls['id'] ? 'selected' : ''; ?>>
                                                    Kelas <?php echo $cls['tingkat'] . ' ' . htmlspecialchars($cls['nama_kelas']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Tempat Lahir</label>
                                        <input type="text" class="form-control" name="tempat_lahir" value="<?php echo htmlspecialchars($student['tempat_lahir'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Tanggal Lahir</label>
                                        <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo $student['tanggal_lahir'] ?? ''; ?>">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Alamat</label>
                                    <textarea class="form-control" name="alamat" rows="3"><?php echo htmlspecialchars($student['alamat'] ?? ''); ?></textarea>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Nomor Telepon</label>
                                        <input type="text" class="form-control" name="nomor_telepon" value="<?php echo htmlspecialchars($student['nomor_telepon'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Status</label>
                                        <select class="form-select" name="status">
                                            <option value="aktif" <?php echo $student['status'] === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                            <option value="pindah" <?php echo $student['status'] === 'pindah' ? 'selected' : ''; ?>>Pindah</option>
                                            <option value="lulus" <?php echo $student['status'] === 'lulus' ? 'selected' : ''; ?>>Lulus</option>
                                            <option value="keluar" <?php echo $student['status'] === 'keluar' ? 'selected' : ''; ?>>Keluar</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
