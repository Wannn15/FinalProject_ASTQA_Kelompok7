<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Tambah Siswa";
$classes = fetch_all(query("SELECT * FROM classes ORDER BY tingkat ASC, nama_kelas ASC"));

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nis = sanitize($_POST['nis'] ?? '');
    $nisn = sanitize($_POST['nisn'] ?? '');
    $nama = sanitize($_POST['nama'] ?? '');
    $jenis_kelamin = sanitize($_POST['jenis_kelamin'] ?? '');
    $tempat_lahir = sanitize($_POST['tempat_lahir'] ?? '');
    $tanggal_lahir = sanitize($_POST['tanggal_lahir'] ?? '');
    $alamat = sanitize($_POST['alamat'] ?? '');
    $nomor_telepon = sanitize($_POST['nomor_telepon'] ?? '');
    $class_id = (int)($_POST['class_id'] ?? 0);
    $status = sanitize($_POST['status'] ?? 'aktif');

    if (empty($nis) || empty($nisn) || empty($nama) || empty($jenis_kelamin) || $class_id <= 0) {
        $error = 'Field wajib harus diisi!';
    } else {
        $sql_check = "SELECT id FROM students WHERE nis = ? OR nisn = ?";
        $stmt = prepare_query($sql_check);
        $stmt->bind_param("ss", $nis, $nisn);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'NIS atau NISN sudah digunakan!';
        } else {
            $sql = "INSERT INTO students (nis, nisn, nama, jenis_kelamin, tempat_lahir, tanggal_lahir, alamat, nomor_telepon, class_id, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = prepare_query($sql);
            $stmt->bind_param("sssssssssi", $nis, $nisn, $nama, $jenis_kelamin, $tempat_lahir, $tanggal_lahir, $alamat, $nomor_telepon, $class_id, $status);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = 'Siswa berhasil ditambahkan!';
                $_SESSION['message_type'] = 'success';
                header("Location: index.php");
                exit;
            } else {
                $error = 'Gagal menambahkan siswa!';
            }
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-person-plus page-header-icon"></i>
                Tambah Siswa
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Tambah Siswa</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">NIS <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="nis" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">NISN <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="nisn" required>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama Siswa <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="nama" required>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                                        <select class="form-select" name="jenis_kelamin" required>
                                            <option value="">-- Pilih --</option>
                                            <option value="Laki-laki">Laki-laki</option>
                                            <option value="Perempuan">Perempuan</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Kelas <span class="text-danger">*</span></label>
                                        <select class="form-select" name="class_id" required>
                                            <option value="">-- Pilih Kelas --</option>
                                            <?php foreach ($classes as $cls): ?>
                                                <option value="<?php echo $cls['id']; ?>">
                                                    Kelas <?php echo $cls['tingkat'] . ' ' . htmlspecialchars($cls['nama_kelas']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Tempat Lahir</label>
                                        <input type="text" class="form-control" name="tempat_lahir">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Tanggal Lahir</label>
                                        <input type="date" class="form-control" name="tanggal_lahir">
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Alamat</label>
                                    <textarea class="form-control" name="alamat" rows="3"></textarea>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Nomor Telepon</label>
                                        <input type="text" class="form-control" name="nomor_telepon">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Status</label>
                                        <select class="form-select" name="status">
                                            <option value="aktif">Aktif</option>
                                            <option value="pindah">Pindah</option>
                                            <option value="lulus">Lulus</option>
                                            <option value="keluar">Keluar</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
