<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

// Ambil semua siswa
$students = fetch_all(query("SELECT s.*, c.nama_kelas, c.tingkat FROM students s INNER JOIN classes c ON s.class_id = c.id ORDER BY s.nama ASC"));

// Set header untuk download file CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="data_siswa_' . date('Y-m-d_H-i-s') . '.csv"');

// Buat output
$output = fopen('php://output', 'w');

// Header kolom
fputcsv($output, [
    'No', 'NIS', 'NISN', 'Nama', 'Jenis Kelamin', 'Tempat Lahir', 'Tanggal Lahir', 
    'Alamat', 'Nomor Telepon', 'Kelas', 'Status', 'Tanggal Dibuat'
], ';');

// Data
foreach ($students as $index => $student) {
    fputcsv($output, [
        $index + 1,
        $student['nis'],
        $student['nisn'],
        $student['nama'],
        $student['jenis_kelamin'],
        $student['tempat_lahir'] ?? '-',
        $student['tanggal_lahir'] ?? '-',
        $student['alamat'] ?? '-',
        $student['nomor_telepon'] ?? '-',
        $student['tingkat'] . ' ' . $student['nama_kelas'],
        $student['status'],
        date('d-m-Y H:i:s', strtotime($student['created_at']))
    ], ';');
}

fclose($output);
exit;
