<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Detail Absensi";
$session_id = (int)($_GET['session_id'] ?? 0);

$session = query("SELECT ats.*, s.hari, s.jam_mulai, s.jam_selesai, t.nama as nama_guru, sub.nama_mapel, c.nama_kelas, c.tingkat 
                  FROM attendance_sessions ats
                  INNER JOIN schedules s ON ats.schedule_id = s.id
                  INNER JOIN teachers t ON s.teacher_id = t.id
                  INNER JOIN subjects sub ON s.subject_id = sub.id
                  INNER JOIN classes c ON s.class_id = c.id
                  WHERE ats.id = $session_id")->fetch_assoc();

if (!$session) {
    header("Location: index.php");
    exit;
}

$details = fetch_all(query("SELECT ad.*, st.nama, st.nis FROM attendance_details ad INNER JOIN students st ON ad.student_id = st.id WHERE ad.session_id = $session_id ORDER BY st.nama ASC"));

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-file-earmark-text page-header-icon"></i>
                Detail Absensi
            </h1>
        </div>

        <div class="page-content">
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Mata Pelajaran:</strong> <?php echo htmlspecialchars($session['nama_mapel']); ?></p>
                            <p><strong>Kelas:</strong> <?php echo $session['tingkat'] . ' ' . htmlspecialchars($session['nama_kelas']); ?></p>
                            <p><strong>Guru:</strong> <?php echo htmlspecialchars($session['nama_guru']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Tanggal:</strong> <?php echo date('d-m-Y', strtotime($session['tanggal'])); ?></p>
                            <p><strong>Hari:</strong> <?php echo htmlspecialchars($session['hari']); ?></p>
                            <p><strong>Jam:</strong> <?php echo $session['jam_mulai'] . ' - ' . $session['jam_selesai']; ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Data Absensi Siswa</h5>
                    <button onclick="window.print()" class="btn btn-primary btn-sm">
                        <i class="bi bi-printer"></i> Cetak
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                    <th>Status</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($details as $index => $detail): ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td><?php echo htmlspecialchars($detail['nis']); ?></td>
                                        <td><?php echo htmlspecialchars($detail['nama']); ?></td>
                                        <td>
                                            <?php if ($detail['status'] === 'hadir'): ?>
                                                <span class="badge bg-success">Hadir</span>
                                            <?php elseif ($detail['status'] === 'sakit'): ?>
                                                <span class="badge bg-warning">Sakit</span>
                                            <?php elseif ($detail['status'] === 'izin'): ?>
                                                <span class="badge bg-info">Izin</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Alfa</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($detail['keterangan'] ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="mt-3">
                <a href="index.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>

    <style media="print">
        .btn, .navbar, .sidebar-admin, .page-header { display: none !important; }
        .main-content { margin-left: 0 !important; }
    </style>

<?php include '../../templates/footer.php'; ?>
