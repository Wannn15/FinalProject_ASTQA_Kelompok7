<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Laporan Absensi";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

$filter_date = $_GET['date'] ?? date('Y-m-d');
$filter_class = $_GET['class'] ?? '';

$sql = "SELECT DISTINCT ats.*, s.hari, s.jam_mulai, s.jam_selesai, t.nama as nama_guru, sub.nama_mapel, c.nama_kelas, c.tingkat 
        FROM attendance_sessions ats
        INNER JOIN schedules s ON ats.schedule_id = s.id
        INNER JOIN teachers t ON s.teacher_id = t.id
        INNER JOIN subjects sub ON s.subject_id = sub.id
        INNER JOIN classes c ON s.class_id = c.id
        WHERE DATE(ats.tanggal) = ?";

if ($filter_class) {
    $sql .= " AND c.id = ?";
    $sessions = fetch_all(prepare_query($sql)->bind_param("si", $filter_date, $filter_class)->get_result());
} else {
    $sessions = fetch_all(prepare_query($sql)->bind_param("s", $filter_date)->get_result());
}

$classes = fetch_all(query("SELECT * FROM classes ORDER BY tingkat ASC, nama_kelas ASC"));
?>

    <div class="container-fluid px-4">
        <?php display_message(); ?>
        
        <div class="page-header">
            <h1>
                <i class="bi bi-file-earmark-text page-header-icon"></i>
                Laporan Absensi
            </h1>
        </div>

        <div class="page-content">
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Filter Laporan</h5>
                </div>
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Tanggal</label>
                            <input type="date" class="form-control" name="date" value="<?php echo $filter_date; ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Kelas</label>
                            <select class="form-select" name="class">
                                <option value="">-- Semua Kelas --</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?php echo $class['id']; ?>" <?php echo $filter_class == $class['id'] ? 'selected' : ''; ?>>
                                        Kelas <?php echo $class['tingkat'] . ' ' . htmlspecialchars($class['nama_kelas']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search"></i> Filter
                            </button>
                            <a href="export.php?date=<?php echo $filter_date; ?><?php echo $filter_class ? '&class=' . $filter_class : ''; ?>" class="btn btn-success">
                                <i class="bi bi-file-earmark-csv"></i> Export CSV
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Daftar Absensi</h5>
                </div>
                <div class="card-body">
                    <?php if (empty($sessions)): ?>
                        <div class="text-center text-muted py-4">Tidak ada data absensi untuk tanggal dan filter yang dipilih</div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($sessions as $session): 
                                $details = fetch_all(query("SELECT ad.*, st.nama, st.nis FROM attendance_details ad INNER JOIN students st ON ad.student_id = st.id WHERE ad.session_id = {$session['id']}"));
                                $hadir = count(array_filter($details, fn($d) => $d['status'] === 'hadir'));
                                $sakit = count(array_filter($details, fn($d) => $d['status'] === 'sakit'));
                                $izin = count(array_filter($details, fn($d) => $d['status'] === 'izin'));
                                $alfa = count(array_filter($details, fn($d) => $d['status'] === 'alfa'));
                                $total = count($details);
                            ?>
                                <div class="col-md-6 mb-3">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <h6 class="card-title"><?php echo htmlspecialchars($session['nama_mapel']) . ' - Kelas ' . $session['tingkat'] . htmlspecialchars($session['nama_kelas']); ?></h6>
                                            <p class="card-text small text-muted">
                                                <?php echo htmlspecialchars($session['nama_guru']); ?> | <?php echo $session['hari']; ?> <?php echo $session['jam_mulai']; ?>-<?php echo $session['jam_selesai']; ?>
                                            </p>
                                            <div class="d-flex gap-2 mb-3">
                                                <span class="badge bg-success badge-hadir">Hadir: <?php echo $hadir; ?></span>
                                                <span class="badge bg-warning badge-sakit">Sakit: <?php echo $sakit; ?></span>
                                                <span class="badge bg-info badge-izin">Izin: <?php echo $izin; ?></span>
                                                <span class="badge bg-danger badge-alfa">Alfa: <?php echo $alfa; ?></span>
                                            </div>
                                            <a href="detail.php?session_id=<?php echo $session['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="bi bi-eye"></i> Lihat Detail
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
