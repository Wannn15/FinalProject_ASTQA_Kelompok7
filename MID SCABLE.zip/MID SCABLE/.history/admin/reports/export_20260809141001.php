<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$filter_date = $_GET['date'] ?? date('Y-m-d');
$filter_class = $_GET['class'] ?? '';

$sql = "SELECT ats.*, s.hari, s.jam_mulai, s.jam_selesai, t.nama as nama_guru, sub.nama_mapel, c.nama_kelas, c.tingkat 
        FROM attendance_sessions ats
        INNER JOIN schedules s ON ats.schedule_id = s.id
        INNER JOIN teachers t ON s.teacher_id = t.id
        INNER JOIN subjects sub ON s.subject_id = sub.id
        INNER JOIN classes c ON s.class_id = c.id
        WHERE DATE(ats.tanggal) = ?";

if ($filter_class) {
    $sql .= " AND c.id = ?";
    $stmt = prepare_query($sql);
    $stmt->bind_param("si", $filter_date, $filter_class);
} else {
    $stmt = prepare_query($sql);
    $stmt->bind_param("s", $filter_date);
}

$stmt->execute();
$sessions = fetch_all($stmt->get_result());

// Set header untuk file CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=laporan_absensi_' . date('Y-m-d_H-i-s') . '.csv');

$output = fopen('php://output', 'w');

// Add BOM untuk UTF-8
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Tulis header CSV
fputcsv($output, [
    'Tanggal',
    'Hari',
    'Jam',
    'Kelas',
    'Mata Pelajaran',
    'Guru',
    'NIS',
    'Nama Siswa',
    'Status',
    'Keterangan'
], ';');

// Tulis data untuk setiap session
foreach ($sessions as $session) {
    $details = fetch_all(query("SELECT ad.*, st.nama, st.nis FROM attendance_details ad INNER JOIN students st ON ad.student_id = st.id WHERE ad.session_id = {$session['id']}"));
    
    foreach ($details as $detail) {
        fputcsv($output, [
            date('d-m-Y', strtotime($session['tanggal'])),
            $session['hari'],
            $session['jam_mulai'] . '-' . $session['jam_selesai'],
            $session['tingkat'] . ' ' . $session['nama_kelas'],
            $session['nama_mapel'],
            $session['nama_guru'],
            $detail['nis'],
            $detail['nama'],
            $detail['status'],
            $detail['keterangan'] ?? ''
        ], ';');
    }
}

fclose($output);
exit;
