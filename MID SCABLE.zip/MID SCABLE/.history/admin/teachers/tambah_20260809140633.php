<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Tambah Guru";
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nip = sanitize($_POST['nip'] ?? '');
    $nama = sanitize($_POST['nama'] ?? '');
    $jenis_kelamin = sanitize($_POST['jenis_kelamin'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $nomor_telepon = sanitize($_POST['nomor_telepon'] ?? '');
    $status = sanitize($_POST['status'] ?? 'aktif');

    if (empty($nip) || empty($nama) || empty($jenis_kelamin)) {
        $error = 'Field wajib harus diisi!';
    } else {
        $sql_check = "SELECT id FROM teachers WHERE nip = ?";
        $stmt = prepare_query($sql_check);
        $stmt->bind_param("s", $nip);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'NIP sudah digunakan!';
        } else {
            $sql = "INSERT INTO teachers (nip, nama, jenis_kelamin, email, nomor_telepon, status) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = prepare_query($sql);
            $stmt->bind_param("ssssss", $nip, $nama, $jenis_kelamin, $email, $nomor_telepon, $status);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = 'Guru berhasil ditambahkan!';
                $_SESSION['message_type'] = 'success';
                header("Location: index.php");
                exit;
            } else {
                $error = 'Gagal menambahkan guru!';
            }
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-person-plus page-header-icon"></i>
                Tambah Guru
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Tambah Guru</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">NIP <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="nip" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="nama" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                                    <select class="form-select" name="jenis_kelamin" required>
                                        <option value="">-- Pilih --</option>
                                        <option value="Laki-laki">Laki-laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nomor Telepon</label>
                                    <input type="text" class="form-control" name="nomor_telepon">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="status">
                                        <option value="aktif">Aktif</option>
                                        <option value="nonaktif">Non-aktif</option>
                                        <option value="cuti">Cuti</option>
                                        <option value="pensiun">Pensiun</option>
                                    </select>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
