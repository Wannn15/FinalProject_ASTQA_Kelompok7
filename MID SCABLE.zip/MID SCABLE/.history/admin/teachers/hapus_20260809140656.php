<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$teacher_id = (int)($_GET['id'] ?? 0);

if (!$teacher_id) {
    header("Location: index.php");
    exit;
}

$sql_delete = "DELETE FROM teachers WHERE id = ?";
$stmt = prepare_query($sql_delete);
$stmt->bind_param("i", $teacher_id);

if ($stmt->execute()) {
    $_SESSION['message'] = 'Guru berhasil dihapus!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Gagal menghapus guru!';
    $_SESSION['message_type'] = 'danger';
}

header("Location: index.php");
exit;
