<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Data Guru";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

$teachers = fetch_all(query("SELECT * FROM teachers ORDER BY nama ASC"));
?>

    <div class="container-fluid px-4">
        <?php display_message(); ?>
        
        <div class="page-header">
            <h1>
                <i class="bi bi-person-badge page-header-icon"></i>
                Data Guru
            </h1>
        </div>

        <div class="page-content">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Guru</h5>
                    <a href="tambah.php" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle"></i> Tambah Guru
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIP</th>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Telepon</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($teachers)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">Tidak ada data guru</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($teachers as $index => $teacher): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($teacher['nip']); ?></td>
                                            <td><?php echo htmlspecialchars($teacher['nama']); ?></td>
                                            <td><?php echo htmlspecialchars($teacher['email'] ?? '-'); ?></td>
                                            <td><?php echo htmlspecialchars($teacher['nomor_telepon'] ?? '-'); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $teacher['status'] === 'aktif' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($teacher['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="edit.php?id=<?php echo $teacher['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="hapus.php?id=<?php echo $teacher['id']; ?>" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
