<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Edit Guru";
$teacher_id = (int)($_GET['id'] ?? 0);
$teacher = query("SELECT * FROM teachers WHERE id = $teacher_id")->fetch_assoc();

if (!$teacher) {
    header("Location: index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = sanitize($_POST['nama'] ?? '');
    $jenis_kelamin = sanitize($_POST['jenis_kelamin'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $nomor_telepon = sanitize($_POST['nomor_telepon'] ?? '');
    $status = sanitize($_POST['status'] ?? 'aktif');

    if (empty($nama) || empty($jenis_kelamin)) {
        $error = 'Field wajib harus diisi!';
    } else {
        $sql = "UPDATE teachers SET nama=?, jenis_kelamin=?, email=?, nomor_telepon=?, status=? WHERE id=?";
        $stmt = prepare_query($sql);
        $stmt->bind_param("sssssi", $nama, $jenis_kelamin, $email, $nomor_telepon, $status, $teacher_id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Guru berhasil diperbarui!';
            $_SESSION['message_type'] = 'success';
            header("Location: index.php");
            exit;
        } else {
            $error = 'Gagal memperbarui guru!';
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-pencil page-header-icon"></i>
                Edit Guru
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Edit Guru</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">NIP</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($teacher['nip']); ?>" disabled>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama</label>
                                    <input type="text" class="form-control" name="nama" value="<?php echo htmlspecialchars($teacher['nama']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Jenis Kelamin</label>
                                    <select class="form-select" name="jenis_kelamin" required>
                                        <option value="Laki-laki" <?php echo $teacher['jenis_kelamin'] === 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
                                        <option value="Perempuan" <?php echo $teacher['jenis_kelamin'] === 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($teacher['email'] ?? ''); ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nomor Telepon</label>
                                    <input type="text" class="form-control" name="nomor_telepon" value="<?php echo htmlspecialchars($teacher['nomor_telepon'] ?? ''); ?>">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="status">
                                        <option value="aktif" <?php echo $teacher['status'] === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                        <option value="nonaktif" <?php echo $teacher['status'] === 'nonaktif' ? 'selected' : ''; ?>>Non-aktif</option>
                                        <option value="cuti" <?php echo $teacher['status'] === 'cuti' ? 'selected' : ''; ?>>Cuti</option>
                                        <option value="pensiun" <?php echo $teacher['status'] === 'pensiun' ? 'selected' : ''; ?>>Pensiun</option>
                                    </select>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
