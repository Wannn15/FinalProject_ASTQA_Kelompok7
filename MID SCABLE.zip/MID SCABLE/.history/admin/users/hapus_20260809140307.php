<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_admin();

$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$user_id) {
    header("Location: index.php");
    exit;
}

// Ambil data user
$user = query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

if (!$user) {
    $_SESSION['message'] = 'User tidak ditemukan!';
    $_SESSION['message_type'] = 'danger';
    header("Location: index.php");
    exit;
}

// Hapus user
$sql_delete = "DELETE FROM users WHERE id = ?";
$stmt = prepare_query($sql_delete);
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    $_SESSION['message'] = 'User berhasil dihapus!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Gagal menghapus user!';
    $_SESSION['message_type'] = 'danger';
}

header("Location: index.php");
exit;
