<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_admin();

$page_title = "Edit User";
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$user_id) {
    header("Location: index.php");
    exit;
}

// Ambil data user
$user = query("SELECT * FROM users WHERE id = $user_id")->fetch_assoc();

if (!$user) {
    $_SESSION['message'] = 'User tidak ditemukan!';
    $_SESSION['message_type'] = 'danger';
    header("Location: index.php");
    exit;
}

// Ambil daftar guru
$teachers = fetch_all(query("SELECT * FROM teachers WHERE status = 'aktif' ORDER BY nama ASC"));

// Proses form submit
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? sanitize($_POST['email']) : '';
    $role = isset($_POST['role']) ? sanitize($_POST['role']) : '';
    $teacher_id = isset($_POST['teacher_id']) ? (int)$_POST['teacher_id'] : null;
    $status = isset($_POST['status']) ? sanitize($_POST['status']) : 'aktif';
    $new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    
    // Validasi
    if (empty($email) || empty($role)) {
        $error = 'Email dan role harus diisi!';
    } elseif (!validate_email($email)) {
        $error = 'Format email tidak valid!';
    } else {
        // Cek apakah email sudah digunakan (jika berbeda)
        if ($email !== $user['email']) {
            $sql_check = "SELECT id FROM users WHERE email = ? AND id != ?";
            $stmt = prepare_query($sql_check);
            $stmt->bind_param("si", $email, $user_id);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows > 0) {
                $error = 'Email sudah digunakan!';
            }
        }
        
        if (!$error) {
            // Update user
            if (!empty($new_password)) {
                if (strlen($new_password) < 6) {
                    $error = 'Password baru minimal 6 karakter!';
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                    $sql_update = "UPDATE users 
                                  SET email = ?, role = ?, teacher_id = ?, status = ?, password = ?
                                  WHERE id = ?";
                    $stmt = prepare_query($sql_update);
                    $stmt->bind_param("ssissi", $email, $role, $teacher_id, $status, $hashed_password, $user_id);
                }
            } else {
                $sql_update = "UPDATE users 
                              SET email = ?, role = ?, teacher_id = ?, status = ?
                              WHERE id = ?";
                $stmt = prepare_query($sql_update);
                $stmt->bind_param("ssisi", $email, $role, $teacher_id, $status, $user_id);
            }
            
            if (!$error && $stmt->execute()) {
                $_SESSION['message'] = 'User berhasil diperbarui!';
                $_SESSION['message_type'] = 'success';
                header("Location: index.php");
                exit;
            } elseif (!$error) {
                $error = 'Gagal memperbarui user!';
            }
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-pencil page-header-icon"></i>
                Edit User
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Edit User</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($error)): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" 
                                           value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                                    <small class="text-muted">Username tidak dapat diubah</small>
                                </div>

                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?php echo htmlspecialchars($user['email']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label for="new_password" class="form-label">Password Baru (Kosongkan jika tidak ingin mengubah)</label>
                                    <input type="password" class="form-control" id="new_password" name="new_password" 
                                           placeholder="Masukkan password baru">
                                    <small class="text-muted">Minimal 6 karakter</small>
                                </div>

                                <div class="mb-3">
                                    <label for="role" class="form-label">Role</label>
                                    <select class="form-select" id="role" name="role" required>
                                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                        <option value="guru" <?php echo $user['role'] === 'guru' ? 'selected' : ''; ?>>Guru</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="teacher_id" class="form-label">Guru (Opsional - untuk Role Guru)</label>
                                    <select class="form-select" id="teacher_id" name="teacher_id">
                                        <option value="">-- Pilih Guru --</option>
                                        <?php foreach ($teachers as $teacher): ?>
                                            <option value="<?php echo $teacher['id']; ?>" 
                                                    <?php echo $user['teacher_id'] == $teacher['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($teacher['nama']); ?> (<?php echo htmlspecialchars($teacher['nip']); ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="aktif" <?php echo $user['status'] === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                        <option value="nonaktif" <?php echo $user['status'] === 'nonaktif' ? 'selected' : ''; ?>>Non-aktif</option>
                                    </select>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
