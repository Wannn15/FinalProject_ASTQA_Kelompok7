<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_admin();

$page_title = "Manajemen User";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

// Ambil semua user
$sql = "SELECT 
    u.*, 
    t.nama as nama_guru
FROM users u
LEFT JOIN teachers t ON u.teacher_id = t.id
ORDER BY u.created_at DESC";

$users = fetch_all(query($sql));
?>

    <div class="container-fluid px-4">
        <!-- Display messages -->
        <?php display_message(); ?>
        
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-person-gear page-header-icon"></i>
                Manajemen User
            </h1>
        </div>

        <div class="page-content">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar User</h5>
                    <a href="tambah.php" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle"></i> Tambah User
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Guru</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($users)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">
                                            Tidak ada data user
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($users as $index => $user): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'danger' : 'primary'; ?>">
                                                    <?php echo ucfirst($user['role']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php echo $user['nama_guru'] ? htmlspecialchars($user['nama_guru']) : '-'; ?>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo $user['status'] === 'aktif' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($user['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="edit.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil"></i> Edit
                                                </a>
                                                <a href="hapus.php?id=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="bi bi-trash"></i> Hapus
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
