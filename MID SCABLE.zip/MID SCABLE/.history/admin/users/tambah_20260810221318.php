<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

// Validasi role
require_admin();

$page_title = "Tambah User";

// Ambil daftar guru
$teachers = fetch_all(query("SELECT * FROM teachers WHERE status = 'aktif' ORDER BY nama ASC"));

// Proses form submit
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? sanitize($_POST['username']) : '';
    $email = isset($_POST['email']) ? sanitize($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $role = isset($_POST['role']) ? sanitize($_POST['role']) : '';
    $teacher_id = isset($_POST['teacher_id']) ? (int)$_POST['teacher_id'] : null;
    $status = isset($_POST['status']) ? sanitize($_POST['status']) : 'aktif';
    
    // Validasi
    if (empty($username) || empty($email) || empty($password) || empty($role)) {
        $error = 'Username, email, password, dan role harus diisi!';
    } elseif (!validate_email($email)) {
        $error = 'Format email tidak valid!';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter!';
    } else {
        // Cek apakah username sudah ada
        $sql_check = "SELECT id FROM users WHERE username = ? OR email = ?";
        $stmt = prepare_query($sql_check);
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'Username atau email sudah digunakan!';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            // Insert user
            $sql_insert = "INSERT INTO users (username, email, password, role, teacher_id, status) 
                          VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = prepare_query($sql_insert);
            $stmt->bind_param("ssssis", $username, $email, $hashed_password, $role, $teacher_id, $status);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = 'User berhasil ditambahkan!';
                $_SESSION['message_type'] = 'success';
                header("Location: index.php");
                exit;
            } else {
                $error = 'Gagal menambahkan user!';
            }
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-person-plus page-header-icon"></i>
                Tambah User
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Tambah User</h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($error)): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" 
                                           placeholder="Masukkan username" required>
                                    <small class="text-muted">Minimal 3 karakter, hanya huruf, angka, dan underscore</small>
                                </div>

                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           placeholder="Masukkan email" required>
                                </div>

                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="password" name="password" 
                                           placeholder="Masukkan password" required>
                                    <small class="text-muted">Minimal 6 karakter</small>
                                </div>

                                <div class="mb-3">
                                    <label for="role" class="form-label">Role</label>
                                    <select class="form-select" id="role" name="role" required>
                                        <option value="">-- Pilih Role --</option>
                                        <option value="admin">Admin</option>
                                        <option value="guru">Guru</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="teacher_id" class="form-label">Guru (Opsional - untuk Role Guru)</label>
                                    <select class="form-select" id="teacher_id" name="teacher_id">
                                        <option value="">-- Pilih Guru --</option>
                                        <?php foreach ($teachers as $teacher): ?>
                                            <option value="<?php echo $teacher['id']; ?>">
                                                <?php echo htmlspecialchars($teacher['nama']); ?> (<?php echo htmlspecialchars($teacher['nip']); ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="aktif">Aktif</option>
                                        <option value="nonaktif">Non-aktif</option>
                                    </select>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
