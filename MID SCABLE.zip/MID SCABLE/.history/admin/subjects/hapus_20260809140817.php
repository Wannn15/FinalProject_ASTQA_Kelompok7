<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$subject_id = (int)($_GET['id'] ?? 0);

if (!$subject_id) {
    header("Location: index.php");
    exit;
}

$sql_delete = "DELETE FROM subjects WHERE id = ?";
$stmt = prepare_query($sql_delete);
$stmt->bind_param("i", $subject_id);

if ($stmt->execute()) {
    $_SESSION['message'] = 'Mata pelajaran berhasil dihapus!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Gagal menghapus mata pelajaran!';
    $_SESSION['message_type'] = 'danger';
}

header("Location: index.php");
exit;
