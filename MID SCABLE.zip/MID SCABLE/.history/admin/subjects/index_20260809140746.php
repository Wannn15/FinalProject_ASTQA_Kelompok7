<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Data Mata Pelajaran";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

$subjects = fetch_all(query("SELECT * FROM subjects ORDER BY nama_mapel ASC"));
?>

    <div class="container-fluid px-4">
        <?php display_message(); ?>
        
        <div class="page-header">
            <h1>
                <i class="bi bi-book page-header-icon"></i>
                Data Mata Pelajaran
            </h1>
        </div>

        <div class="page-content">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Mata Pelajaran</h5>
                    <a href="tambah.php" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle"></i> Tambah Mapel
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Kode</th>
                                    <th>Nama Mata Pelajaran</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($subjects)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-4">Tidak ada data mata pelajaran</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($subjects as $index => $subject): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo htmlspecialchars($subject['kode_mapel']); ?></td>
                                            <td><?php echo htmlspecialchars($subject['nama_mapel']); ?></td>
                                            <td>
                                                <a href="edit.php?id=<?php echo $subject['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="hapus.php?id=<?php echo $subject['id']; ?>" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
