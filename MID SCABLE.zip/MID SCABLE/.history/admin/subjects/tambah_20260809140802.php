<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Tambah Mata Pelajaran";
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode_mapel = sanitize($_POST['kode_mapel'] ?? '');
    $nama_mapel = sanitize($_POST['nama_mapel'] ?? '');

    if (empty($kode_mapel) || empty($nama_mapel)) {
        $error = 'Kode dan nama mata pelajaran harus diisi!';
    } else {
        $sql_check = "SELECT id FROM subjects WHERE kode_mapel = ?";
        $stmt = prepare_query($sql_check);
        $stmt->bind_param("s", $kode_mapel);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'Kode mata pelajaran sudah ada!';
        } else {
            $sql = "INSERT INTO subjects (kode_mapel, nama_mapel) VALUES (?, ?)";
            $stmt = prepare_query($sql);
            $stmt->bind_param("ss", $kode_mapel, $nama_mapel);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = 'Mata pelajaran berhasil ditambahkan!';
                $_SESSION['message_type'] = 'success';
                header("Location: index.php");
                exit;
            } else {
                $error = 'Gagal menambahkan mata pelajaran!';
            }
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-plus-circle page-header-icon"></i>
                Tambah Mata Pelajaran
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Tambah Mata Pelajaran</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Kode Mata Pelajaran</label>
                                    <input type="text" class="form-control" name="kode_mapel" placeholder="Contoh: MTK" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama Mata Pelajaran</label>
                                    <input type="text" class="form-control" name="nama_mapel" placeholder="Contoh: Matematika" required>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
