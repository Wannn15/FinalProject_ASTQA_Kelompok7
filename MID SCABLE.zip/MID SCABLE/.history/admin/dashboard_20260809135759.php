<?php
session_start();
require_once '../config/database.php';
require_once '../config/auth.php';

// Validasi role
require_admin();

$page_title = "Dashboard Admin";
include '../templates/header.php';
include '../templates/navbar.php';
include '../templates/sidebar_admin.php';

// Ambil statistik
$total_users = query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$total_students = query("SELECT COUNT(*) as count FROM students WHERE status = 'aktif'")->fetch_assoc()['count'];
$total_teachers = query("SELECT COUNT(*) as count FROM teachers WHERE status = 'aktif'")->fetch_assoc()['count'];
$total_classes = query("SELECT COUNT(*) as count FROM classes")->fetch_assoc()['count'];
$total_subjects = query("SELECT COUNT(*) as count FROM subjects")->fetch_assoc()['count'];

// Absensi hari ini
$hari_ini = date('Y-m-d');
$sql_attendance_today = "SELECT 
    SUM(CASE WHEN status = 'hadir' THEN 1 ELSE 0 END) as hadir,
    SUM(CASE WHEN status = 'sakit' THEN 1 ELSE 0 END) as sakit,
    SUM(CASE WHEN status = 'izin' THEN 1 ELSE 0 END) as izin,
    SUM(CASE WHEN status = 'alfa' THEN 1 ELSE 0 END) as alfa
FROM attendance_details ad
INNER JOIN attendance_sessions asess ON ad.session_id = asess.id
WHERE asess.tanggal = ?";

$stmt = prepare_query($sql_attendance_today);
$stmt->bind_param("s", $hari_ini);
$stmt->execute();
$attendance_today = $stmt->get_result()->fetch_assoc();

// Siswa terbaru
$sql_new_students = "SELECT * FROM students ORDER BY created_at DESC LIMIT 5";
$new_students = fetch_all(query($sql_new_students));

// Absensi terbaru
$sql_latest_attendance = "SELECT 
    ad.*, 
    s.nama as nama_siswa, 
    asess.tanggal,
    sc.hari,
    t.nama as nama_guru,
    sub.nama_mapel
FROM attendance_details ad
INNER JOIN attendance_sessions asess ON ad.session_id = asess.id
INNER JOIN schedules sc ON asess.schedule_id = sc.id
INNER JOIN students s ON ad.student_id = s.id
INNER JOIN teachers t ON sc.teacher_id = t.id
INNER JOIN subjects sub ON sc.subject_id = sub.id
ORDER BY ad.created_at DESC
LIMIT 10";
$latest_attendance = fetch_all(query($sql_latest_attendance));

// Jadwal hari ini
$hari_ini_text = strtoupper(strftime('%A', strtotime($hari_ini)));
$hari_mapping = array(
    'SUNDAY' => 'Minggu',
    'MONDAY' => 'Senin',
    'TUESDAY' => 'Selasa',
    'WEDNESDAY' => 'Rabu',
    'THURSDAY' => 'Kamis',
    'FRIDAY' => 'Jumat',
    'SATURDAY' => 'Sabtu'
);
$hari_indo = $hari_mapping[$hari_ini_text] ?? 'Hari tidak dikenal';

$sql_today_schedules = "SELECT 
    sc.*, 
    t.nama as nama_guru, 
    sub.nama_mapel,
    c.nama_kelas
FROM schedules sc
INNER JOIN teachers t ON sc.teacher_id = t.id
INNER JOIN subjects sub ON sc.subject_id = sub.id
INNER JOIN classes c ON sc.class_id = c.id
WHERE sc.hari = ?
ORDER BY sc.jam_mulai ASC";

$stmt = prepare_query($sql_today_schedules);
$stmt->bind_param("s", $hari_indo);
$stmt->execute();
$today_schedules = fetch_all($stmt->get_result());
?>

    <div class="container-fluid px-4">
        <!-- Display messages -->
        <?php display_message(); ?>
        
        <!-- Page Header -->
        <div class="page-header">
            <h1>
                <i class="bi bi-speedometer2 page-header-icon"></i>
                Dashboard Admin
            </h1>
        </div>

        <!-- Statistics Cards -->
        <div class="page-content">
            <div class="row mb-4">
                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #667eea;">
                            <i class="bi bi-person-gear"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $total_users; ?></div>
                        <div class="stat-card-label">Total User</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #28a745;">
                            <i class="bi bi-people"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $total_students; ?></div>
                        <div class="stat-card-label">Total Siswa</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #ffc107;">
                            <i class="bi bi-person-badge"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $total_teachers; ?></div>
                        <div class="stat-card-label">Total Guru</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-3 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #17a2b8;">
                            <i class="bi bi-building"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $total_classes; ?></div>
                        <div class="stat-card-label">Total Kelas</div>
                    </div>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col-md-6 col-lg-2 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #dc3545;">
                            <i class="bi bi-book"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $total_subjects; ?></div>
                        <div class="stat-card-label">Total Mata Pelajaran</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-2 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #28a745;">
                            <i class="bi bi-check-circle"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $attendance_today['hadir'] ?? 0; ?></div>
                        <div class="stat-card-label">Hadir Hari Ini</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-2 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #17a2b8;">
                            <i class="bi bi-hospital"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $attendance_today['sakit'] ?? 0; ?></div>
                        <div class="stat-card-label">Sakit Hari Ini</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-2 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #ffc107;">
                            <i class="bi bi-exclamation-circle"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $attendance_today['izin'] ?? 0; ?></div>
                        <div class="stat-card-label">Izin Hari Ini</div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-2 mb-3">
                    <div class="stat-card">
                        <div class="stat-card-icon" style="color: #dc3545;">
                            <i class="bi bi-x-circle"></i>
                        </div>
                        <div class="stat-card-number"><?php echo $attendance_today['alfa'] ?? 0; ?></div>
                        <div class="stat-card-label">Alfa Hari Ini</div>
                    </div>
                </div>
            </div>

            <!-- Row untuk tiga card besar -->
            <div class="row">
                <!-- Jadwal Hari Ini -->
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header bg-light border-bottom">
                            <h5 class="mb-0">
                                <i class="bi bi-calendar-event" style="color: #667eea;"></i>
                                Jadwal Hari Ini (<?php echo $hari_indo; ?>)
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($today_schedules)): ?>
                                <div class="text-center text-muted py-3">
                                    <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                    <p class="mt-2">Tidak ada jadwal hari ini</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($today_schedules as $schedule): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($schedule['nama_mapel']); ?></h6>
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars($schedule['nama_guru']); ?> | 
                                                        <?php echo htmlspecialchars($schedule['nama_kelas']); ?>
                                                    </small>
                                                </div>
                                                <span class="badge bg-primary">
                                                    <?php echo $schedule['jam_mulai']; ?> - <?php echo $schedule['jam_selesai']; ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Siswa Terbaru -->
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header bg-light border-bottom">
                            <h5 class="mb-0">
                                <i class="bi bi-person-plus" style="color: #28a745;"></i>
                                Siswa Terbaru
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($new_students)): ?>
                                <div class="text-center text-muted py-3">
                                    <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                    <p class="mt-2">Belum ada siswa</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($new_students as $student): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div>
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($student['nama']); ?></h6>
                                                    <small class="text-muted">
                                                        NIS: <?php echo htmlspecialchars($student['nis']); ?> | 
                                                        <?php 
                                                        $class = query("SELECT nama_kelas FROM classes WHERE id = " . $student['class_id'])->fetch_assoc();
                                                        echo htmlspecialchars($class['nama_kelas'] ?? 'Kelas');
                                                        ?>
                                                    </small>
                                                </div>
                                                <span class="badge bg-success">
                                                    <?php echo ucfirst($student['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Absensi Terbaru -->
                <div class="col-md-12 col-lg-4 mb-4">
                    <div class="card">
                        <div class="card-header bg-light border-bottom">
                            <h5 class="mb-0">
                                <i class="bi bi-clock-history" style="color: #17a2b8;"></i>
                                Absensi Terbaru
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($latest_attendance)): ?>
                                <div class="text-center text-muted py-3">
                                    <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                    <p class="mt-2">Belum ada absensi</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach ($latest_attendance as $att): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-start">
                                                <div style="flex: 1;">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($att['nama_siswa']); ?></h6>
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars($att['nama_mapel']); ?>
                                                    </small>
                                                </div>
                                                <span class="badge badge-<?php echo strtolower($att['status']); ?>">
                                                    <?php echo ucfirst($att['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../templates/footer.php'; ?>
