<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Tambah Kelas";
$teachers = fetch_all(query("SELECT * FROM teachers WHERE status = 'aktif' ORDER BY nama ASC"));
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tingkat = (int)($_POST['tingkat'] ?? 0);
    $nama_kelas = sanitize($_POST['nama_kelas'] ?? '');
    $wali_kelas_id = (int)($_POST['wali_kelas_id'] ?? 0) ?: null;

    if ($tingkat <= 0 || empty($nama_kelas)) {
        $error = 'Tingkat dan nama kelas harus diisi!';
    } else {
        $sql_check = "SELECT id FROM classes WHERE tingkat = ? AND nama_kelas = ?";
        $stmt = prepare_query($sql_check);
        $stmt->bind_param("is", $tingkat, $nama_kelas);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'Kelas sudah ada!';
        } else {
            $sql = "INSERT INTO classes (tingkat, nama_kelas, wali_kelas_id) VALUES (?, ?, ?)";
            $stmt = prepare_query($sql);
            $stmt->bind_param("iss", $tingkat, $nama_kelas, $wali_kelas_id);
            
            if ($stmt->execute()) {
                $_SESSION['message'] = 'Kelas berhasil ditambahkan!';
                $_SESSION['message_type'] = 'success';
                header("Location: index.php");
                exit;
            } else {
                $error = 'Gagal menambahkan kelas!';
            }
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-plus-circle page-header-icon"></i>
                Tambah Kelas
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Tambah Kelas</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                                    <select class="form-select" name="tingkat" required>
                                        <option value="">-- Pilih --</option>
                                        <option value="7">7</option>
                                        <option value="8">8</option>
                                        <option value="9">9</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama Kelas <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="nama_kelas" placeholder="Contoh: A, B, C" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Wali Kelas</label>
                                    <select class="form-select" name="wali_kelas_id">
                                        <option value="">-- Pilih Guru --</option>
                                        <?php foreach ($teachers as $teacher): ?>
                                            <option value="<?php echo $teacher['id']; ?>">
                                                <?php echo htmlspecialchars($teacher['nama']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
