<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Edit Kelas";
$class_id = (int)($_GET['id'] ?? 0);
$class = query("SELECT * FROM classes WHERE id = $class_id")->fetch_assoc();

if (!$class) {
    header("Location: index.php");
    exit;
}

$teachers = fetch_all(query("SELECT * FROM teachers WHERE status = 'aktif' ORDER BY nama ASC"));
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tingkat = (int)($_POST['tingkat'] ?? 0);
    $nama_kelas = sanitize($_POST['nama_kelas'] ?? '');
    $wali_kelas_id = (int)($_POST['wali_kelas_id'] ?? 0) ?: null;

    if ($tingkat <= 0 || empty($nama_kelas)) {
        $error = 'Tingkat dan nama kelas harus diisi!';
    } else {
        $sql = "UPDATE classes SET tingkat=?, nama_kelas=?, wali_kelas_id=? WHERE id=?";
        $stmt = prepare_query($sql);
        $stmt->bind_param("issi", $tingkat, $nama_kelas, $wali_kelas_id, $class_id);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = 'Kelas berhasil diperbarui!';
            $_SESSION['message_type'] = 'success';
            header("Location: index.php");
            exit;
        } else {
            $error = 'Gagal memperbarui kelas!';
        }
    }
}

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';
?>

    <div class="container-fluid px-4">
        <div class="page-header">
            <h1>
                <i class="bi bi-pencil page-header-icon"></i>
                Edit Kelas
            </h1>
        </div>

        <div class="page-content">
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Form Edit Kelas</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Tingkat</label>
                                    <select class="form-select" name="tingkat" required>
                                        <option value="7" <?php echo $class['tingkat'] == 7 ? 'selected' : ''; ?>>7</option>
                                        <option value="8" <?php echo $class['tingkat'] == 8 ? 'selected' : ''; ?>>8</option>
                                        <option value="9" <?php echo $class['tingkat'] == 9 ? 'selected' : ''; ?>>9</option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Nama Kelas</label>
                                    <input type="text" class="form-control" name="nama_kelas" value="<?php echo htmlspecialchars($class['nama_kelas']); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Wali Kelas</label>
                                    <select class="form-select" name="wali_kelas_id">
                                        <option value="">-- Pilih Guru --</option>
                                        <?php foreach ($teachers as $teacher): ?>
                                            <option value="<?php echo $teacher['id']; ?>" <?php echo $class['wali_kelas_id'] == $teacher['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($teacher['nama']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-save"></i> Simpan
                                    </button>
                                    <a href="index.php" class="btn btn-secondary">
                                        <i class="bi bi-arrow-left"></i> Batal
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
