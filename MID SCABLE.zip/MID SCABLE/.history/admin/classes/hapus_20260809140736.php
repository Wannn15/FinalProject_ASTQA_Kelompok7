<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$class_id = (int)($_GET['id'] ?? 0);

if (!$class_id) {
    header("Location: index.php");
    exit;
}

$sql_delete = "DELETE FROM classes WHERE id = ?";
$stmt = prepare_query($sql_delete);
$stmt->bind_param("i", $class_id);

if ($stmt->execute()) {
    $_SESSION['message'] = 'Kelas berhasil dihapus!';
    $_SESSION['message_type'] = 'success';
} else {
    $_SESSION['message'] = 'Gagal menghapus kelas!';
    $_SESSION['message_type'] = 'danger';
}

header("Location: index.php");
exit;
