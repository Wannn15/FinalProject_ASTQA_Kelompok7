<?php
session_start();
require_once '../../config/database.php';
require_once '../../config/auth.php';

require_admin();

$page_title = "Data Kelas";

include '../../templates/header.php';
include '../../templates/navbar.php';
include '../../templates/sidebar_admin.php';

$classes = fetch_all(query("SELECT c.*, t.nama as nama_guru FROM classes c LEFT JOIN teachers t ON c.wali_kelas_id = t.id ORDER BY c.tingkat ASC, c.nama_kelas ASC"));
?>

    <div class="container-fluid px-4">
        <?php display_message(); ?>
        
        <div class="page-header">
            <h1>
                <i class="bi bi-building page-header-icon"></i>
                Data Kelas
            </h1>
        </div>

        <div class="page-content">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Kelas</h5>
                    <a href="tambah.php" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle"></i> Tambah Kelas
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tingkat</th>
                                    <th>Nama Kelas</th>
                                    <th>Wali Kelas</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($classes)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">Tidak ada data kelas</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($classes as $index => $class): ?>
                                        <tr>
                                            <td><?php echo $index + 1; ?></td>
                                            <td><?php echo $class['tingkat']; ?></td>
                                            <td><?php echo htmlspecialchars($class['nama_kelas']); ?></td>
                                            <td><?php echo $class['nama_guru'] ? htmlspecialchars($class['nama_guru']) : '-'; ?></td>
                                            <td>
                                                <a href="edit.php?id=<?php echo $class['id']; ?>" class="btn btn-warning btn-sm">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="hapus.php?id=<?php echo $class['id']; ?>" class="btn btn-danger btn-sm btn-delete">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../../templates/footer.php'; ?>
