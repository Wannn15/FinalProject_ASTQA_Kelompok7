<?php
/**
 * COMPREHENSIVE SYSTEM CHECK v2
 * URL: http://localhost/MID%20SCABLE/system_check.php
 */

session_start();
require_once 'config/database.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>System Check Report</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #f5f5f5; }
        .check-section { background: white; margin: 15px 0; padding: 20px; border-radius: 5px; border-left: 4px solid #667eea; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .warning { color: orange; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #f9f9f9; font-weight: bold; }
        code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; }
    </style>
</head>
<body>
<h1>[SYSTEM] Complete System Check Report</h1>
<hr>";

$errors = [];
$warnings = [];
$success_count = 0;

// ===== 1. DATABASE CONFIG =====
echo "<div class='check-section'>
<h2>1. Database Configuration</h2>";

if (defined('DB_HOST') && defined('DB_USER') && defined('DB_NAME')) {
    echo "<p><span class='success'>[OK]</span> Database constants defined</p>";
    echo "<table><tr><th>Setting</th><th>Value</th></tr>";
    echo "<tr><td>DB_HOST</td><td><code>" . DB_HOST . "</code></td></tr>";
    echo "<tr><td>DB_NAME</td><td><code>" . DB_NAME . "</code></td></tr>";
    echo "<tr><td>BASE_PATH</td><td><code>" . BASE_PATH . "</code></td></tr>";
    echo "</table>";
    $success_count++;
} else {
    echo "<p><span class='error'>[ERROR]</span> Database constants NOT defined</p>";
    $errors[] = "Database constants missing";
}

if (!$mysqli->connect_error) {
    echo "<p><span class='success'>[OK]</span> Database connection OK</p>";
    $success_count++;
} else {
    echo "<p><span class='error'>[ERROR]</span> Database connection FAILED: " . $mysqli->connect_error . "</p>";
    $errors[] = "Database connection failed";
}
echo "</div>";

// ===== 2. HELPER FUNCTIONS =====
echo "<div class='check-section'>
<h2>2. Helper Functions</h2>";

$functions = ['get_url', 'is_current_page', 'query', 'prepare_query', 'fetch_all', 'escape_string'];
foreach ($functions as $func) {
    if (function_exists($func)) {
        echo "<p><span class='success'>[OK]</span> Function <code>$func()</code> exists</p>";
        $success_count++;
    } else {
        echo "<p><span class='error'>[ERROR]</span> Function <code>$func()</code> NOT found</p>";
        $errors[] = "Function '$func' missing";
    }
}
echo "</div>";

// ===== 3. DATABASE TABLES =====
echo "<div class='check-section'>
<h2>3. Database Tables</h2>";

$tables = ['users', 'teachers', 'classes', 'students', 'subjects', 'schedules', 'attendance_sessions', 'attendance_details'];
echo "<table><tr><th>Table</th><th>Status</th><th>Row Count</th></tr>";

foreach ($tables as $table) {
    $result = $mysqli->query("SHOW TABLES LIKE '$table'");
    $count_result = $mysqli->query("SELECT COUNT(*) as cnt FROM $table");
    $count_row = $count_result->fetch_assoc();
    
    if ($result && $result->num_rows > 0) {
        echo "<tr><td><code>$table</code></td><td><span class='success'>[OK] Exists</span></td><td>" . $count_row['cnt'] . " rows</td></tr>";
        $success_count++;
    } else {
        echo "<tr><td><code>$table</code></td><td><span class='error'>[ERROR] Missing</span></td><td>-</td></tr>";
        $errors[] = "Table '$table' missing";
    }
}
echo "</table></div>";

// ===== 4. USER DATA =====
echo "<div class='check-section'>
<h2>4. User Accounts</h2>";

$result = $mysqli->query("SELECT id, email, role, status FROM users ORDER BY role");
echo "<table><tr><th>ID</th><th>Email</th><th>Role</th><th>Status</th></tr>";

$admin_count = 0;
$teacher_count = 0;

while ($row = $result->fetch_assoc()) {
    $status_class = $row['status'] === 'aktif' ? 'success' : 'warning';
    echo "<tr>
        <td>{$row['id']}</td>
        <td><code>{$row['email']}</code></td>
        <td>{$row['role']}</td>
        <td><span class='$status_class'>{$row['status']}</span></td>
    </tr>";
    
    if ($row['role'] === 'admin') $admin_count++;
    if ($row['role'] === 'guru') $teacher_count++;
}
echo "</table>";

if ($admin_count > 0) {
    echo "<p><span class='success'>[OK]</span> Admin users: <strong>$admin_count</strong></p>";
    $success_count++;
} else {
    echo "<p><span class='error'>[ERROR]</span> No admin users found</p>";
    $errors[] = "No admin users";
}

if ($teacher_count > 0) {
    echo "<p><span class='success'>[OK]</span> Teacher users: <strong>$teacher_count</strong></p>";
    $success_count++;
} else {
    echo "<p><span class='warning'>[WARNING]</span> No teacher users found</p>";
    $warnings[] = "No teacher users";
}
echo "</div>";

// ===== 5. PASSWORD TEST =====
echo "<div class='check-section'>
<h2>5. Password Verification Test</h2>";

$result = $mysqli->query("SELECT email, password FROM users WHERE email='admin@sekolah.com' LIMIT 1");
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "<p>Testing admin password...</p>";
    echo "<table><tr><th>Email</th><th>Password Hash</th></tr>";
    echo "<tr><td><code>" . $user['email'] . "</code></td><td><code>" . substr($user['password'], 0, 40) . "...</code></td></tr>";
    echo "</table>";
    
    // Test different passwords
    $test_passwords = [
        'admin123' => 'Expected password',
        'guru123' => 'Teacher password',
        'test123' => 'Random test'
    ];
    
    echo "<p>Testing password verification:</p>";
    $password_ok = false;
    foreach ($test_passwords as $pwd => $desc) {
        if (password_verify($pwd, $user['password'])) {
            echo "<p><span class='success'>[OK]</span> Password <code>$pwd</code> matches! ($desc)</p>";
            $password_ok = true;
            $success_count++;
        } else {
            echo "<p><span class='error'>[ERROR]</span> Password <code>$pwd</code> does NOT match ($desc)</p>";
        }
    }
    
    if (!$password_ok) {
        $errors[] = "Admin password hash incorrect";
    }
} else {
    echo "<p><span class='error'>[ERROR]</span> Admin user not found</p>";
    $errors[] = "Admin user not found";
}
echo "</div>";

// ===== 6. CRITICAL FILES =====
echo "<div class='check-section'>
<h2>6. Critical Files</h2>";

$files = [
    'config/database.php' => 'Database config',
    'config/auth.php' => 'Auth helper',
    'auth/login.php' => 'Login page',
    'auth/process_login.php' => 'Login processor',
    'auth/logout.php' => 'Logout',
    'admin/dashboard.php' => 'Admin dashboard',
    'teacher/dashboard.php' => 'Teacher dashboard',
    'templates/header.php' => 'Header template',
    'templates/navbar.php' => 'Navbar',
    'templates/sidebar_admin.php' => 'Admin sidebar',
    'templates/sidebar_teacher.php' => 'Teacher sidebar'
];

echo "<table><tr><th>File</th><th>Status</th></tr>";
foreach ($files as $file => $desc) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "<tr><td><code>$file</code></td><td><span class='success'>[OK]</span></td></tr>";
        $success_count++;
    } else {
        echo "<tr><td><code>$file</code></td><td><span class='error'>[ERROR] Missing</span></td></tr>";
        $errors[] = "File '$file' missing";
    }
}
echo "</table></div>";

// ===== 7. PHP REQUIREMENTS =====
echo "<div class='check-section'>
<h2>7. PHP Requirements</h2>";

echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";
echo "<table><tr><th>Extension</th><th>Status</th></tr>";

$extensions = ['mysqli', 'json', 'session', 'hash', 'spl'];
foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "<tr><td><code>$ext</code></td><td><span class='success'>[OK] Loaded</span></td></tr>";
        $success_count++;
    } else {
        echo "<tr><td><code>$ext</code></td><td><span class='error'>[ERROR] NOT Loaded</span></td></tr>";
        $errors[] = "Extension '$ext' not loaded";
    }
}
echo "</table></div>";

// ===== 8. SUMMARY =====
echo "<div class='check-section' style='border-left-color: #28a745;'>
<h2>[REPORT] Summary</h2>";

echo "<p><strong>Checks Passed:</strong> <span class='success'>$success_count [OK]</span></p>";
echo "<p><strong>Warnings:</strong> <span class='warning'>" . count($warnings) . " [WARNING]</span></p>";
echo "<p><strong>Errors:</strong> <span class='error'>" . count($errors) . " [ERROR]</span></p>";

if (count($errors) === 0) {
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; color: #155724; margin: 15px 0;'>";
    echo "<strong>[SUCCESS] ALL SYSTEMS OPERATIONAL!</strong><br>";
    echo "System is ready to use. You can proceed with testing.";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24; margin: 15px 0;'>";
    echo "<strong>[ERROR] ERRORS DETECTED:</strong><br>";
    foreach ($errors as $error) {
        echo "- $error<br>";
    }
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center; margin-top: 20px;'>";
echo "<a href='" . BASE_PATH . "/auth/login.php' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>[GO] Login</a>";
echo "<a href='" . BASE_PATH . "/auto_fix.php' style='padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>[FIX] Auto Repair</a>";
echo "<a href='" . BASE_PATH . "/diagnostic.php' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>[INFO] Diagnostic</a>";
echo "</p>";
echo "</div>";
echo "</body></html>";
?>

if (defined('DB_HOST') && defined('DB_USER') && defined('DB_NAME')) {
    echo "<p><span class='success'>✅</span> Database constants defined</p>";
    echo "<table><tr><th>Setting</th><th>Value</th></tr>";
    echo "<tr><td>DB_HOST</td><td><code>" . DB_HOST . "</code></td></tr>";
    echo "<tr><td>DB_NAME</td><td><code>" . DB_NAME . "</code></td></tr>";
    echo "<tr><td>BASE_PATH</td><td><code>" . BASE_PATH . "</code></td></tr>";
    echo "</table>";
    $success_count++;
} else {
    echo "<p><span class='error'>❌</span> Database constants NOT defined</p>";
    $errors[] = "Database constants missing";
}

if (!$mysqli->connect_error) {
    echo "<p><span class='success'>✅</span> Database connection OK</p>";
    $success_count++;
} else {
    echo "<p><span class='error'>❌</span> Database connection FAILED: " . $mysqli->connect_error . "</p>";
    $errors[] = "Database connection failed";
}
echo "</div>";

// ===== 2. HELPER FUNCTIONS =====
echo "<div class='check-section'>
<h2>2️⃣ Helper Functions</h2>";

$functions = ['get_url', 'is_current_page', 'query', 'prepare_query', 'fetch_all', 'escape_string'];
foreach ($functions as $func) {
    if (function_exists($func)) {
        echo "<p><span class='success'>✅</span> Function <code>$func()</code> exists</p>";
        $success_count++;
    } else {
        echo "<p><span class='error'>❌</span> Function <code>$func()</code> NOT found</p>";
        $errors[] = "Function '$func' missing";
    }
}
echo "</div>";

// ===== 3. DATABASE TABLES =====
echo "<div class='check-section'>
<h2>3️⃣ Database Tables</h2>";

$tables = ['users', 'teachers', 'classes', 'students', 'subjects', 'schedules', 'attendance_sessions', 'attendance_details'];
echo "<table><tr><th>Table</th><th>Status</th><th>Row Count</th></tr>";

foreach ($tables as $table) {
    $result = $mysqli->query("SHOW TABLES LIKE '$table'");
    $count_result = $mysqli->query("SELECT COUNT(*) as cnt FROM $table");
    $count_row = $count_result->fetch_assoc();
    
    if ($result && $result->num_rows > 0) {
        echo "<tr><td><code>$table</code></td><td><span class='success'>✅ Exists</span></td><td>" . $count_row['cnt'] . " rows</td></tr>";
        $success_count++;
    } else {
        echo "<tr><td><code>$table</code></td><td><span class='error'>❌ Missing</span></td><td>-</td></tr>";
        $errors[] = "Table '$table' missing";
    }
}
echo "</table></div>";

// ===== 4. USER DATA =====
echo "<div class='check-section'>
<h2>4️⃣ User Accounts</h2>";

$result = $mysqli->query("SELECT id, email, role, status FROM users ORDER BY role");
echo "<table><tr><th>ID</th><th>Email</th><th>Role</th><th>Status</th></tr>";

$admin_count = 0;
$teacher_count = 0;

while ($row = $result->fetch_assoc()) {
    $status_class = $row['status'] === 'aktif' ? 'success' : 'warning';
    echo "<tr>
        <td>{$row['id']}</td>
        <td><code>{$row['email']}</code></td>
        <td>{$row['role']}</td>
        <td><span class='$status_class'>{$row['status']}</span></td>
    </tr>";
    
    if ($row['role'] === 'admin') $admin_count++;
    if ($row['role'] === 'guru') $teacher_count++;
}
echo "</table>";

if ($admin_count > 0) {
    echo "<p><span class='success'>✅</span> Admin users: <strong>$admin_count</strong></p>";
    $success_count++;
} else {
    echo "<p><span class='error'>❌</span> No admin users found</p>";
    $errors[] = "No admin users";
}

if ($teacher_count > 0) {
    echo "<p><span class='success'>✅</span> Teacher users: <strong>$teacher_count</strong></p>";
    $success_count++;
} else {
    echo "<p><span class='warning'>⚠️</span> No teacher users found</p>";
    $warnings[] = "No teacher users";
}
echo "</div>";

// ===== 5. PASSWORD TEST =====
echo "<div class='check-section'>
<h2>5️⃣ Password Verification Test</h2>";

$result = $mysqli->query("SELECT email, password FROM users WHERE email='admin@sekolah.com' LIMIT 1");
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "<p>Testing admin password...</p>";
    echo "<table><tr><th>Email</th><th>Password Hash</th></tr>";
    echo "<tr><td><code>" . $user['email'] . "</code></td><td><code>" . substr($user['password'], 0, 40) . "...</code></td></tr>";
    echo "</table>";
    
    // Test different passwords
    $test_passwords = [
        'admin123' => 'Expected password',
        'guru123' => 'Teacher password',
        'test123' => 'Random test'
    ];
    
    echo "<p>Testing password verification:</p>";
    $password_ok = false;
    foreach ($test_passwords as $pwd => $desc) {
        if (password_verify($pwd, $user['password'])) {
            echo "<p><span class='success'>✅</span> Password <code>$pwd</code> matches! ($desc)</p>";
            $password_ok = true;
            $success_count++;
        } else {
            echo "<p><span class='error'>❌</span> Password <code>$pwd</code> does NOT match ($desc)</p>";
        }
    }
    
    if (!$password_ok) {
        $errors[] = "Admin password hash incorrect";
    }
} else {
    echo "<p><span class='error'>❌</span> Admin user not found</p>";
    $errors[] = "Admin user not found";
}
echo "</div>";

// ===== 6. CRITICAL FILES =====
echo "<div class='check-section'>
<h2>6️⃣ Critical Files</h2>";

$files = [
    'config/database.php' => 'Database config',
    'config/auth.php' => 'Auth helper',
    'auth/login.php' => 'Login page',
    'auth/process_login.php' => 'Login processor',
    'auth/logout.php' => 'Logout',
    'admin/dashboard.php' => 'Admin dashboard',
    'teacher/dashboard.php' => 'Teacher dashboard',
    'templates/header.php' => 'Header template',
    'templates/navbar.php' => 'Navbar',
    'templates/sidebar_admin.php' => 'Admin sidebar',
    'templates/sidebar_teacher.php' => 'Teacher sidebar'
];

echo "<table><tr><th>File</th><th>Status</th></tr>";
foreach ($files as $file => $desc) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        echo "<tr><td><code>$file</code></td><td><span class='success'>✅ OK</span></td></tr>";
        $success_count++;
    } else {
        echo "<tr><td><code>$file</code></td><td><span class='error'>❌ Missing</span></td></tr>";
        $errors[] = "File '$file' missing";
    }
}
echo "</table></div>";

// ===== 7. PHP REQUIREMENTS =====
echo "<div class='check-section'>
<h2>7️⃣ PHP Requirements</h2>";

echo "<p><strong>PHP Version:</strong> " . phpversion() . "</p>";
echo "<table><tr><th>Extension</th><th>Status</th></tr>";

$extensions = ['mysqli', 'json', 'session', 'hash', 'spl'];
foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "<tr><td><code>$ext</code></td><td><span class='success'>✅ Loaded</span></td></tr>";
        $success_count++;
    } else {
        echo "<tr><td><code>$ext</code></td><td><span class='error'>❌ NOT Loaded</span></td></tr>";
        $errors[] = "Extension '$ext' not loaded";
    }
}
echo "</table></div>";

// ===== 8. SUMMARY =====
echo "<div class='check-section' style='border-left-color: #28a745;'>
<h2>📊 SUMMARY</h2>";

echo "<p><strong>Checks Passed:</strong> <span class='success'>$success_count ✅</span></p>";
echo "<p><strong>Warnings:</strong> <span class='warning'>" . count($warnings) . " ⚠️</span></p>";
echo "<p><strong>Errors:</strong> <span class='error'>" . count($errors) . " ❌</span></p>";

if (count($errors) === 0) {
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; color: #155724; margin: 15px 0;'>";
    echo "<strong>🎉 ALL SYSTEMS OPERATIONAL!</strong><br>";
    echo "System is ready to use. You can proceed with testing.";
    echo "</div>";
} else {
    echo "<div style='background: #f8d7da; padding: 15px; border-radius: 5px; color: #721c24; margin: 15px 0;'>";
    echo "<strong>⚠️ ERRORS DETECTED:</strong><br>";
    foreach ($errors as $error) {
        echo "• $error<br>";
    }
    echo "</div>";
}

echo "<hr>";
echo "<p style='text-align: center; margin-top: 20px;'>";
echo "<a href='" . BASE_PATH . "/auth/login.php' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>🔐 Go to Login</a>";
echo "<a href='" . BASE_PATH . "/reset_password.php' style='padding: 10px 20px; background: #ffc107; color: black; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>🔑 Reset Password</a>";
echo "<a href='" . BASE_PATH . "/diagnostic.php' style='padding: 10px 20px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>📋 Full Diagnostic</a>";
echo "</p>";
echo "</div>";
echo "</body></html>";
?>
