<?php
/**
 * AUTOMATIC SYSTEM REPAIR & INITIALIZATION
 * URL: http://localhost/MID%20SCABLE/auto_fix.php
 * 
 * This script automatically fixes common issues
 */

session_start();
require_once 'config/database.php';

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Auto Fix System</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #f5f5f5; }
        .fix-section { background: white; margin: 15px 0; padding: 20px; border-radius: 5px; border-left: 4px solid #667eea; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .info { color: blue; font-weight: bold; }
    </style>
</head>
<body>
<h1>[AUTO] System Repair Tool</h1>
<hr>";

// ===== 1. RESET ALL PASSWORDS =====
echo "<div class='fix-section'>
<h2>1. Resetting All Passwords</h2>";

$passwords = [
    'admin@sekolah.com' => 'admin123',
    'budi@sekolah.com' => 'guru123',
    'siti@sekolah.com' => 'guru123',
    'ahmad@sekolah.com' => 'guru123',
    'dewi@sekolah.com' => 'guru123'
];

foreach ($passwords as $email => $plain_password) {
    $hashed = password_hash($plain_password, PASSWORD_BCRYPT);
    
    $sql = "UPDATE users SET password = ? WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ss", $hashed, $email);
        if ($stmt->execute()) {
            echo "<p><span class='success'>[OK]</span> $email - Password reset to '<code>$plain_password</code>'</p>";
        } else {
            echo "<p><span class='error'>[ERROR]</span> $email - Update failed</p>";
        }
        $stmt->close();
    } else {
        echo "<p><span class='error'>[ERROR]</span> $email - Prepare failed</p>";
    }
}
echo "</div>";

// ===== 2. VERIFY USERS =====
echo "<div class='fix-section'>
<h2>2. Verifying User Accounts</h2>";

$result = $mysqli->query("SELECT id, email, role, status FROM users");
echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%;'>
<tr style='background: #f0f0f0;'><th>ID</th><th>Email</th><th>Role</th><th>Status</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td><code>{$row['email']}</code></td><td><strong>{$row['role']}</strong></td><td>{$row['status']}</td></tr>";
}
echo "</table>";
echo "</div>";

// ===== 3. CHECK TEACHERS =====
echo "<div class='fix-section'>
<h2>3. Verifying Teachers</h2>";

$result = $mysqli->query("SELECT id, nip, nama, email, status FROM teachers");
echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%;'>
<tr style='background: #f0f0f0;'><th>ID</th><th>NIP</th><th>Nama</th><th>Email</th><th>Status</th></tr>";

$teacher_count = 0;
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['nip']}</td><td>{$row['nama']}</td><td><code>{$row['email']}</code></td><td>{$row['status']}</td></tr>";
    $teacher_count++;
}
echo "</table>";
echo "<p><span class='info'>[INFO]</span> Total teachers: <strong>$teacher_count</strong></p>";
echo "</div>";

// ===== 4. CHECK STUDENTS =====
echo "<div class='fix-section'>
<h2>4. Verifying Students</h2>";

$result = $mysqli->query("SELECT COUNT(*) as cnt FROM students");
$row = $result->fetch_assoc();
$student_count = $row['cnt'];

echo "<p><span class='info'>[INFO]</span> Total students: <strong>$student_count</strong></p>";

if ($student_count === 0) {
    echo "<p><span class='error'>[WARNING] No students in database</span></p>";
} else {
    echo "<p><span class='success'>[OK] Students data available</span></p>";
}
echo "</div>";

// ===== 5. CHECK CLASSES =====
echo "<div class='fix-section'>
<h2>5. Verifying Classes</h2>";

$result = $mysqli->query("SELECT id, tingkat, nama_kelas FROM classes ORDER BY tingkat, nama_kelas");
echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%;'>
<tr style='background: #f0f0f0;'><th>ID</th><th>Tingkat</th><th>Nama Kelas</th></tr>";

$class_count = 0;
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>Kelas {$row['tingkat']}</td><td>{$row['nama_kelas']}</td></tr>";
    $class_count++;
}
echo "</table>";
echo "<p><span class='info'>[INFO]</span> Total classes: <strong>$class_count</strong></p>";
echo "</div>";

// ===== 6. FINAL SUMMARY =====
echo "<div class='fix-section' style='border-left-color: #28a745;'>
<h2>[SUCCESS] REPAIR COMPLETE</h2>";

echo "<h3>Login Credentials</h3>";
echo "<table border='1' cellpadding='10' cellspacing='0' style='width: 100%;'>
<tr style='background: #f0f0f0;'><th>Role</th><th>Email</th><th>Password</th></tr>";
echo "<tr><td><strong>Admin</strong></td><td><code>admin@sekolah.com</code></td><td><code>admin123</code></td></tr>";
echo "<tr><td><strong>Guru</strong></td><td><code>budi@sekolah.com</code></td><td><code>guru123</code></td></tr>";
echo "<tr><td></td><td><code>siti@sekolah.com</code></td><td><code>guru123</code></td></tr>";
echo "<tr><td></td><td><code>ahmad@sekolah.com</code></td><td><code>guru123</code></td></tr>";
echo "<tr><td></td><td><code>dewi@sekolah.com</code></td><td><code>guru123</code></td></tr>";
echo "</table>";

echo "<h3 style='margin-top: 20px;'>Next Steps</h3>";
echo "<ol>";
echo "<li>Clear your browser cache (Ctrl+Shift+Delete)</li>";
echo "<li>Go to: " . BASE_PATH . "/auth/login.php</li>";
echo "<li>Login with email and password from above</li>";
echo "<li>Test all menu items</li>";
echo "</ol>";

echo "<div style='background: #d4edda; padding: 15px; border-radius: 5px; color: #155724; margin: 20px 0;'>";
echo "<strong>[SUCCESS] System is ready to use!</strong><br>";
echo "All passwords have been reset and verified.";
echo "</div>";

echo "</div>";

echo "<hr>";
echo "<p style='text-align: center; margin-top: 20px;'>";
echo "<a href='" . BASE_PATH . "/auth/login.php' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; display: inline-block;'>[GO] Login Page</a>";
echo "</p>";
echo "</body></html>";
?>
