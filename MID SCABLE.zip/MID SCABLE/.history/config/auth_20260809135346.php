<?php
/**
 * Authentication dan Authorization Helper
 * File: config/auth.php
 */

require_once __DIR__ . '/database.php';

/**
 * Fungsi untuk cek apakah user sudah login
 */
function is_logged_in() {
    return isset($_SESSION['id']) && isset($_SESSION['role']);
}

/**
 * Fungsi untuk cek apakah user adalah admin
 */
function is_admin() {
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

/**
 * Fungsi untuk cek apakah user adalah guru
 */
function is_teacher() {
    return is_logged_in() && $_SESSION['role'] === 'guru';
}

/**
 * Fungsi untuk require login
 * Jika belum login, redirect ke halaman login
 */
function require_login() {
    if (!is_logged_in()) {
        header("Location: " . get_base_url() . "auth/login.php");
        exit;
    }
}

/**
 * Fungsi untuk require admin
 * Jika bukan admin, redirect ke halaman yang sesuai
 */
function require_admin() {
    require_login();
    
    if ($_SESSION['role'] !== 'admin') {
        header("Location: " . get_base_url() . "index.php");
        exit;
    }
}

/**
 * Fungsi untuk require guru
 * Jika bukan guru, redirect ke halaman yang sesuai
 */
function require_teacher() {
    require_login();
    
    if ($_SESSION['role'] !== 'guru') {
        header("Location: " . get_base_url() . "index.php");
        exit;
    }
}

/**
 * Fungsi untuk mendapatkan base URL project
 */
function get_base_url() {
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
    $host = $_SERVER['HTTP_HOST'];
    $script = dirname($_SERVER['SCRIPT_NAME']);
    
    // Hilangkan trailing slash jika ada
    $base_url = $protocol . "://" . $host . $script . "/";
    
    return $base_url;
}

/**
 * Fungsi untuk mendapatkan informasi user yang login
 */
function get_user_info($user_id) {
    global $mysqli;
    
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Fungsi untuk mendapatkan informasi guru yang login (jika user adalah guru)
 */
function get_teacher_info($user_id) {
    global $mysqli;
    
    $sql = "SELECT t.* FROM teachers t
            INNER JOIN users u ON u.teacher_id = t.id
            WHERE u.id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Fungsi untuk sanitasi input
 */
function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Fungsi untuk validasi email
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Fungsi untuk redirect dengan message
 */
function redirect($url, $message = null, $type = 'info') {
    if ($message) {
        $_SESSION['message'] = $message;
        $_SESSION['message_type'] = $type;
    }
    header("Location: " . $url);
    exit;
}

/**
 * Fungsi untuk menampilkan message dari session
 */
function display_message() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        $type = $_SESSION['message_type'] ?? 'info';
        
        echo '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">';
        echo $message;
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        echo '</div>';
        
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
}
