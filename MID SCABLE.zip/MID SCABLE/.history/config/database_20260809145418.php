<?php
/**
 * Konfigurasi Database
 * File: config/database.php
 */

// Konfigurasi koneksi database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'sistem_absensi_sekolah');

// Base path untuk URL
define('BASE_PATH', '/MID%20SCABLE');

// Buat koneksi
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Periksa koneksi
if ($mysqli->connect_error) {
    die("Koneksi gagal: " . $mysqli->connect_error);
}

// Set charset
$mysqli->set_charset("utf8mb4");

// Fungsi untuk menjalankan query
function query($sql) {
    global $mysqli;
    $result = $mysqli->query($sql);
    
    if (!$result) {
        die("Query error: " . $mysqli->error);
    }
    
    return $result;
}

// Fungsi untuk prepared statement
function prepare_query($sql) {
    global $mysqli;
    $stmt = $mysqli->prepare($sql);
    
    if (!$stmt) {
        die("Prepare error: " . $mysqli->error);
    }
    
    return $stmt;
}

// Fungsi untuk fetch data
function fetch_all($result) {
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    return $data;
}

// Fungsi untuk fetch satu data
function fetch_one($result) {
    return $result->fetch_assoc();
}

// Fungsi untuk escape string (security)
function escape_string($string) {
    global $mysqli;
    return $mysqli->real_escape_string($string);
}

/**
 * Helper function untuk generate URL yang benar
 * Menangani spasi di folder name
 */
function get_url($path) {
    return BASE_PATH . '/' . ltrim($path, '/');
}

/**
 * Helper function untuk cek current page
 */
function is_current_page($page_keyword) {
    return strpos($_SERVER['PHP_SELF'], $page_keyword) !== false;
}
