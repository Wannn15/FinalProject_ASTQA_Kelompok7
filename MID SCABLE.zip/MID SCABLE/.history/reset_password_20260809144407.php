<?php
/**
 * Script Reset Password - Jalankan sekali untuk fix password hash
 * URL: http://localhost/MID%20SCABLE/reset_password.php
 */

require_once 'config/database.php';

// Password yang akan di-hash
$passwords = [
    'admin' => 'admin123',
    'budi' => 'guru123',
    'siti' => 'guru123',
    'ahmad' => 'guru123',
    'dewi' => 'guru123'
];

echo "<h2>🔐 Reset Password Users</h2>";
echo "<hr>";

// Hash semua password menggunakan bcrypt
$updates = [];
foreach ($passwords as $email_prefix => $plain_password) {
    $hashed = password_hash($plain_password, PASSWORD_BCRYPT);
    
    if ($email_prefix === 'admin') {
        $email = 'admin@sekolah.com';
    } else {
        $email = $email_prefix . '@sekolah.com';
    }
    
    $sql = "UPDATE users SET password = ? WHERE email = ?";
    $stmt = prepare_query($sql);
    $stmt->bind_param("ss", $hashed, $email);
    $result = $stmt->execute();
    
    if ($result) {
        echo "✅ <strong>$email</strong> - Password reset berhasil!<br>";
        echo "   📝 Password baru: <code>$plain_password</code><br>";
        echo "   🔒 Hash: <code>" . substr($hashed, 0, 30) . "...</code><br><br>";
    } else {
        echo "❌ <strong>$email</strong> - Gagal! Error: " . $stmt->error . "<br><br>";
    }
    
    $stmt->close();
}

echo "<hr>";
echo "<p style='color: green; font-weight: bold;'>✨ Semua password sudah direset!</p>";
echo "<p>Silakan <strong>hapus file ini</strong> setelah selesai: <code>reset_password.php</code></p>";
echo "<p><a href='auth/login.php' style='padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>Kembali ke Login</a></p>";
?>
