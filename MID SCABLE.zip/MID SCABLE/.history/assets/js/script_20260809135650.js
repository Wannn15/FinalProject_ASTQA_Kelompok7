// File: assets/js/script.js
// Untuk custom scripts

document.addEventListener('DOMContentLoaded', function() {
    // Semua custom JavaScript akan ditambahkan di sini
    
    // Contoh: Konfirmasi sebelum delete
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Apakah Anda yakin ingin menghapus data ini?')) {
                e.preventDefault();
            }
        });
    });
});
