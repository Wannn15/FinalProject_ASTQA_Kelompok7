<?php
// File: templates/sidebar_admin.php
// Pastikan sudah login sebagai admin sebelum menggunakan file ini
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <h5><i class="bi bi-shield-check"></i> ADMIN</h5>
        <p><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></p>
    </div>

    <ul class="sidebar-menu">
        <!-- Dashboard -->
        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'dashboard.php' : BASE_PATH . '/admin/dashboard.php'; ?>" 
               class="sidebar-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <!-- Data Master -->
        <div class="sidebar-menu-group-title">DATA MASTER</div>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'users/index.php' : BASE_PATH . '/admin/users/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'users') !== false ? 'active' : ''; ?>">
                <i class="bi bi-person-gear"></i>
                <span>User</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'students/index.php' : BASE_PATH . '/admin/students/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'students') !== false ? 'active' : ''; ?>">
                <i class="bi bi-people"></i>
                <span>Siswa</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'teachers/index.php' : BASE_PATH . '/admin/teachers/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'teachers') !== false ? 'active' : ''; ?>">
                <i class="bi bi-person-badge"></i>
                <span>Guru</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'classes/index.php' : BASE_PATH . '/admin/classes/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'classes') !== false ? 'active' : ''; ?>">
                <i class="bi bi-building"></i>
                <span>Kelas</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'subjects/index.php' : BASE_PATH . '/admin/subjects/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'subjects') !== false ? 'active' : ''; ?>">
                <i class="bi bi-book"></i>
                <span>Mata Pelajaran</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'schedules/index.php' : BASE_PATH . '/admin/schedules/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'schedules') !== false ? 'active' : ''; ?>">
                <i class="bi bi-calendar-event"></i>
                <span>Jadwal</span>
            </a>
        </li>

        <!-- Absensi -->
        <div class="sidebar-menu-group-title">ABSENSI</div>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? 'reports/index.php' : BASE_PATH . '/admin/reports/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'reports') !== false ? 'active' : ''; ?>">
                <i class="bi bi-file-earmark-bar-graph"></i>
                <span>Laporan Absensi</span>
            </a>
        </li>

        <!-- Logout -->
        <div class="sidebar-divider"></div>
    </ul>

    <div class="sidebar-logout">
        <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../auth/logout.php' : '../../auth/logout.php'; ?>">
            <i class="bi bi-box-arrow-right"></i> Logout
        </a>
    </div>
</aside>

<div class="main-content">
