<?php
// File: templates/footer.php
?>
    </div> <!-- End main-content -->

    <footer style="margin-left: 250px; padding: 30px; background: white; border-top: 1px solid #e0e0e0; text-align: center; color: #666; font-size: 0.9rem;">
        <p>&copy; <?php echo date('Y'); ?> Sistem Informasi Sekolah dan Absensi. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false || strpos($_SERVER['PHP_SELF'], '/teacher/') !== false) ? '../../assets/js/script.js' : 'assets/js/script.js'; ?>"></script>
    
    <?php
    // Tampilkan flash message dari session jika ada
    if (isset($_SESSION['message'])) {
        $type = $_SESSION['message_type'] ?? 'info';
        $message = $_SESSION['message'];
        echo '<script>';
        echo "document.addEventListener('DOMContentLoaded', function() {";
        echo "  var alertDiv = document.createElement('div');";
        echo "  alertDiv.className = 'alert alert-" . htmlspecialchars($type) . " alert-dismissible fade show';";
        echo "  alertDiv.setAttribute('role', 'alert');";
        echo "  alertDiv.style.position = 'fixed';";
        echo "  alertDiv.style.top = '80px';";
        echo "  alertDiv.style.right = '20px';";
        echo "  alertDiv.style.zIndex = '2000';";
        echo "  alertDiv.style.minWidth = '300px';";
        echo "  alertDiv.innerHTML = '" . htmlspecialchars($message) . "<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"Close\"></button>';";
        echo "  document.body.appendChild(alertDiv);";
        echo "  setTimeout(function() {";
        echo "    alertDiv.remove();";
        echo "  }, 5000);";
        echo "});";
        echo '</script>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
    ?>
</body>
</html>
