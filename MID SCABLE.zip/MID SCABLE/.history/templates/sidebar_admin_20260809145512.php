<?php
// File: templates/sidebar_admin.php
// Pastikan sudah login sebagai admin sebelum menggunakan file ini
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <h5><i class="bi bi-shield-check"></i> ADMIN</h5>
        <p><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></p>
    </div>

    <ul class="sidebar-menu">
        <!-- Dashboard -->
        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/dashboard.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('dashboard') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <!-- Data Master -->
        <div class="sidebar-menu-group-title">DATA MASTER</div>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/users/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('users') ? 'active' : ''; ?>">
                <i class="bi bi-person-gear"></i>
                <span>User</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/students/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('students') ? 'active' : ''; ?>">
                <i class="bi bi-people"></i>
                <span>Siswa</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/teachers/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('teachers') ? 'active' : ''; ?>">
                <i class="bi bi-person-badge"></i>
                <span>Guru</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/classes/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('classes') ? 'active' : ''; ?>">
                <i class="bi bi-building"></i>
                <span>Kelas</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/subjects/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('subjects') ? 'active' : ''; ?>">
                <i class="bi bi-book"></i>
                <span>Mata Pelajaran</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/schedules/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('schedules') ? 'active' : ''; ?>">
                <i class="bi bi-calendar-event"></i>
                <span>Jadwal</span>
            </a>
        </li>

        <!-- Absensi -->
        <div class="sidebar-menu-group-title">ABSENSI</div>

        <li class="sidebar-menu-item">
            <a href="<?php echo get_url('/admin/reports/index.php'); ?>" 
               class="sidebar-menu-link <?php echo is_current_page('reports') ? 'active' : ''; ?>">
                <i class="bi bi-file-earmark-bar-graph"></i>
                <span>Laporan Absensi</span>
            </a>
        </li>

        <!-- Logout -->
        <div class="sidebar-divider"></div>
    </ul>

    <div class="sidebar-logout">
        <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../auth/logout.php' : '../../auth/logout.php'; ?>">
            <i class="bi bi-box-arrow-right"></i> Logout
        </a>
    </div>
</aside>

<div class="main-content">
