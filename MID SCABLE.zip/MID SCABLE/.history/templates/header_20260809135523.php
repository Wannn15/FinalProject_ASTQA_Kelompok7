<?php
// File: templates/header.php
// Untuk memberitahu bahwa session sudah dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>Sistem Informasi Sekolah dan Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../../assets/css/style.css' : (strpos($_SERVER['PHP_SELF'], '/teacher/') !== false ? '../../assets/css/style.css' : 'assets/css/style.css'); ?>">
    <style>
        :root {
            --primary-color: #667eea;
            --secondary-color: #764ba2;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f6fa;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding-top: 20px;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar-brand {
            padding: 0 20px 30px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 20px;
        }
        
        .sidebar-brand h5 {
            margin: 0;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .sidebar-brand p {
            margin: 5px 0 0;
            font-size: 0.85rem;
            opacity: 0.9;
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .sidebar-menu-group-title {
            padding: 15px 20px;
            font-size: 0.85rem;
            font-weight: bold;
            color: rgba(255, 255, 255, 0.7);
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .sidebar-menu-item {
            padding: 0;
        }
        
        .sidebar-menu-link {
            display: block;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        
        .sidebar-menu-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar-menu-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            color: white;
            border-left-color: white;
        }
        
        .sidebar-menu-link i {
            margin-right: 10px;
            width: 20px;
        }
        
        .sidebar-divider {
            height: 1px;
            background-color: rgba(255, 255, 255, 0.1);
            margin: 15px 0;
        }
        
        .sidebar-logout {
            position: absolute;
            bottom: 20px;
            left: 0;
            right: 0;
            padding: 0 15px;
        }
        
        .sidebar-logout a {
            display: block;
            padding: 12px 20px;
            background-color: rgba(255, 255, 255, 0.1);
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-align: center;
            font-weight: 600;
        }
        
        .sidebar-logout a:hover {
            background-color: rgba(220, 53, 69, 0.7);
            color: white;
        }
        
        .main-content {
            margin-left: 250px;
            padding-top: 70px;
            min-height: 100vh;
        }
        
        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            position: fixed;
            width: calc(100% - 250px);
            left: 250px;
            top: 0;
            z-index: 999;
        }
        
        .navbar-brand {
            font-weight: bold;
            color: #667eea;
        }
        
        .navbar .nav-link {
            color: #555;
            transition: all 0.3s ease;
        }
        
        .navbar .nav-link:hover {
            color: #667eea;
        }
        
        .navbar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #555;
        }
        
        .navbar-user-badge {
            display: inline-block;
            padding: 5px 12px;
            background: #f0f0f0;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            color: #667eea;
        }
        
        .page-header {
            padding: 30px 0;
            border-bottom: 1px solid #e0e0e0;
            background: white;
            margin-bottom: 30px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .page-header h1 {
            margin: 0;
            color: #333;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .page-header-icon {
            font-size: 2rem;
            color: #667eea;
        }
        
        .page-content {
            padding: 30px 0;
        }
        
        .card {
            border: none;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        
        .table {
            margin-bottom: 0;
        }
        
        .table thead th {
            background-color: #f8f9fa;
            border-top: none;
            color: #333;
            font-weight: 600;
            border-bottom: 2px solid #e0e0e0;
        }
        
        .btn {
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .badge-hadir {
            background-color: #28a745;
            color: white;
        }
        
        .badge-sakit {
            background-color: #17a2b8;
            color: white;
        }
        
        .badge-izin {
            background-color: #ffc107;
            color: black;
        }
        
        .badge-alfa {
            background-color: #dc3545;
            color: white;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            text-align: center;
        }
        
        .stat-card-icon {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .stat-card-number {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        
        .stat-card-label {
            color: #666;
            font-size: 0.95rem;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
                padding-top: 0;
            }
            
            .navbar {
                position: relative;
                width: 100%;
                left: 0;
            }
            
            .page-header h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
