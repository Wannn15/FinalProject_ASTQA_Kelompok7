<?php
// File: templates/sidebar_teacher.php
// Pastikan sudah login sebagai guru sebelum menggunakan file ini
?>
<aside class="sidebar">
    <div class="sidebar-brand">
        <h5><i class="bi bi-mortarboard"></i> GURU</h5>
        <p><?php echo htmlspecialchars($_SESSION['username'] ?? ''); ?></p>
    </div>

    <ul class="sidebar-menu">
        <!-- Dashboard -->
        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/teacher/') !== false) ? 'dashboard.php' : '../teacher/dashboard.php'; ?>" 
               class="sidebar-menu-link <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <!-- Absensi -->
        <div class="sidebar-menu-group-title">ABSENSI</div>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/teacher/') !== false) ? 'attendance/index.php' : '../teacher/attendance/index.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'attendance') !== false ? 'active' : ''; ?>">
                <i class="bi bi-calendar-check"></i>
                <span>Jadwal Saya</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/teacher/') !== false) ? 'attendance/input.php' : '../teacher/attendance/input.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'input') !== false ? 'active' : ''; ?>">
                <i class="bi bi-pencil-square"></i>
                <span>Input Absensi</span>
            </a>
        </li>

        <li class="sidebar-menu-item">
            <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/teacher/') !== false) ? 'attendance/history.php' : '../teacher/attendance/history.php'; ?>" 
               class="sidebar-menu-link <?php echo strpos($_SERVER['PHP_SELF'], 'history') !== false ? 'active' : ''; ?>">
                <i class="bi bi-clock-history"></i>
                <span>Riwayat Absensi</span>
            </a>
        </li>

        <!-- Logout -->
        <div class="sidebar-divider"></div>
    </ul>

    <div class="sidebar-logout">
        <a href="<?php echo (strpos($_SERVER['PHP_SELF'], '/teacher/') !== false) ? '../auth/logout.php' : '../../auth/logout.php'; ?>">
            <i class="bi bi-box-arrow-right"></i> Logout
        </a>
    </div>
</aside>

<div class="main-content">
