<?php
// File: templates/navbar.php
// Pastikan header.php sudah di-include sebelum navbar.php
?>
<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container-fluid px-4">
        <span class="navbar-brand">
            <i class="bi bi-building"></i> Sistem Informasi Sekolah
        </span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <div class="navbar-user">
                <span class="navbar-user-badge">
                    <?php 
                    if (isset($_SESSION['role'])) {
                        echo ucfirst($_SESSION['role']);
                    }
                    ?>
                </span>
                <i class="bi bi-person-circle" style="font-size: 1.5rem; color: #667eea;"></i>
                <span><?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
            </div>
        </div>
    </div>
</nav>
