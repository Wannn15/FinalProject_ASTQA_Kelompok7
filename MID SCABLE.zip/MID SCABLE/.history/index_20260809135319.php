<?php
session_start();

// Jika sudah login, redirect ke dashboard sesuai role
if (isset($_SESSION['id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } elseif ($_SESSION['role'] === 'guru') {
        header("Location: teacher/dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Sekolah dan Absensi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .welcome-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 60px 40px;
            text-align: center;
            max-width: 600px;
            width: 100%;
        }
        .welcome-icon {
            font-size: 80px;
            color: #667eea;
            margin-bottom: 20px;
        }
        .welcome-title {
            color: #333;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .welcome-subtitle {
            color: #666;
            margin-bottom: 40px;
            font-size: 1.1rem;
        }
        .btn-welcome {
            padding: 12px 40px;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            margin-top: 20px;
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        .info-box {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 20px;
            margin-top: 30px;
            text-align: left;
            border-radius: 8px;
        }
        .info-box h6 {
            color: #667eea;
            margin-bottom: 10px;
            font-weight: bold;
        }
        .info-box p {
            margin: 5px 0;
            color: #555;
            font-size: 0.95rem;
        }
    </style>
</head>
<body>
    <div class="welcome-container">
        <div class="welcome-icon">
            <i class="bi bi-building"></i>
        </div>
        <h1 class="welcome-title">Sistem Informasi Sekolah dan Absensi</h1>
        <p class="welcome-subtitle">Manajemen Data Siswa dan Sistem Absensi Terintegrasi</p>
        
        <a href="auth/login.php" class="btn btn-welcome btn-login">
            <i class="bi bi-box-arrow-in-right"></i> Masuk ke Sistem
        </a>

        <div class="info-box">
            <h6><i class="bi bi-info-circle"></i> Informasi Login</h6>
            <p><strong>Admin:</strong></p>
            <p>• Username: <code>admin</code></p>
            <p>• Password: <code>admin123</code></p>
            
            <p class="mt-3"><strong>Guru:</strong></p>
            <p>• Username: <code>budi</code>, <code>siti</code>, <code>ahmad</code>, atau <code>dewi</code></p>
            <p>• Password: <code>guru123</code></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
