# 🚀 QUICK START GUIDE - 5 Menit

Panduan cepat untuk menjalankan Sistem Informasi Sekolah dan Absensi dalam 5 menit.

---

## ⚡ Prerequisites Check

Pastikan sudah terinstall:
- ✅ PHP 7.4+ (check: `php -v`)
- ✅ MySQL 5.7+ (check: `mysql -V`)
- ✅ Web Server running (Apache/Nginx)

---

## 1️⃣ Copy Project (1 menit)

```bash
# Copy folder ke root web server
# Windows XAMPP: C:\xampp\htdocs\
# Linux: /var/www/html/
# macOS: /Library/WebServer/Documents/

# Atau clone jika dari git:
git clone <repository> sistem_absensi
cd sistem_absensi
```

---

## 2️⃣ Import Database (2 menit)

### Option A: MySQL Command Line
```bash
mysql -u root -p < database/database.sql
```
Tekan Enter saat diminta password (jika kosong).

### Option B: phpMyAdmin
1. Buka: `http://localhost/phpmyadmin`
2. Login (user: root, password: kosong)
3. Klik menu "Import"
4. Pilih file: `database/database.sql`
5. Klik "Go"

---

## 3️⃣ Verify Installation (1 menit)

```bash
# Cek database exist
mysql -u root -p -e "SHOW DATABASES LIKE 'sistem%';"

# Cek tables
mysql -u root -p -e "USE sistem_absensi_sekolah; SHOW TABLES;"
```

Output harus:
```
Database: sistem_absensi_sekolah
Tables: 8 (users, teachers, classes, students, subjects, schedules, attendance_sessions, attendance_details)
```

---

## 4️⃣ Access Application (1 menit)

Buka browser dan akses:
```
http://localhost/sistem_absensi
```

Anda akan diarahkan ke login page.

---

## 🔑 Login dengan Default Accounts

### Admin Account
```
Username: admin
Password: admin123
```

### Guru Account (Pilih Salah Satu)
```
Username: budi / siti / ahmad / dewi
Password: guru123
```

---

## ✨ Selesai! Anda Siap Menggunakan Sistem

### Untuk Admin:
1. Login sebagai `admin`
2. Explore menu di sidebar:
   - Dashboard → Lihat statistik
   - Data Master → Kelola guru, siswa, kelas, mapel, jadwal
   - Absensi → Lihat laporan & export

### Untuk Guru:
1. Login sebagai `budi` (atau guru lainnya)
2. Klik "Input Absensi"
3. Pilih jadwal mengajar
4. Pilih tanggal
5. Isi status siswa
6. Simpan

---

## 📝 Troubleshooting Cepat

### "Can't connect to MySQL"
```bash
# Windows: Buka XAMPP Control Panel, start MySQL
# Linux: sudo systemctl start mysql
# macOS: brew services start mysql
```

### "Database tidak ditemukan"
```bash
# Re-import database
mysql -u root -p < database/database.sql
```

### "White page atau 404"
1. Restart web server
2. Pastikan URL benar: `http://localhost/sistem_absensi`
3. Pastikan folder berada di web root directory

### "Login gagal"
```bash
# Reset dengan:
mysql -u root -p < database/database.sql
# Gunakan default: admin / admin123
```

---

## 📚 Full Documentation

- **README.md** - Fitur lengkap & dokumentasi
- **INSTALLATION.md** - Setup detail & troubleshooting
- **CHECKLIST.md** - Verifikasi semua fitur

---

## 🔒 Security Reminder

> ⚠️ **PENTING**: Ubah password semua akun setelah login pertama!

---

## ✅ Anda Selesai!

Sistem Anda sudah siap digunakan. Mulai dengan:
1. Setup master data (guru, siswa, kelas)
2. Buat jadwal mengajar
3. Create user untuk setiap guru
4. Test input absensi
5. Generate laporan

---

**Need Help?** → Lihat INSTALLATION.md untuk troubleshooting lengkap.

**Ready to Go!** 🎉
