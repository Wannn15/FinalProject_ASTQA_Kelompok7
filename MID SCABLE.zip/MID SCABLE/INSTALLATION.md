# Panduan Instalasi Sistem Informasi Sekolah dan Absensi

## Persyaratan Sistem

- **PHP**: 7.4 atau lebih tinggi
- **MySQL**: 5.7 atau lebih tinggi
- **Web Server**: Apache 2.4+ atau Nginx
- **Browser**: Chrome, Firefox, Safari, atau Edge terbaru
- **OS**: Windows, Linux, atau macOS

## Langkah-Langkah Instalasi

### 1. Persiapan Environment

#### Untuk Windows (XAMPP)
```
1. Download XAMPP dari https://www.apachefriends.org/
2. Install XAMPP (pilih PHP 7.4+, MySQL 5.7+)
3. Buka XAMPP Control Panel
4. Start Apache dan MySQL
```

#### Untuk Linux
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install apache2 php php-mysql mysql-server

# Aktifkan mod_rewrite
sudo a2enmod rewrite
sudo systemctl restart apache2
```

#### Untuk macOS
```bash
# Menggunakan Homebrew
brew install php mysql apache2
```

### 2. Download dan Ekstrak Project

```bash
# Clone atau copy project ke folder web server
# XAMPP: C:\xampp\htdocs\sistem_absensi
# Linux: /var/www/html/sistem_absensi
# macOS: /Library/WebServer/Documents/sistem_absensi

cd /path/to/webroot
git clone <repository-url> sistem_absensi
# atau
cp -r sistem_absensi /path/to/webroot/
```

### 3. Konfigurasi Database

#### Buka MySQL Command Line atau phpMyAdmin

**Opsi A: Menggunakan MySQL Command Line**
```bash
mysql -u root -p

# Ketika diminta password, tekan Enter (jika belum ada password)

# Kemudian execute file SQL:
mysql -u root -p < /path/to/sistem_absensi/database/database.sql
```

**Opsi B: Menggunakan phpMyAdmin**
```
1. Buka browser: http://localhost/phpmyadmin
2. Login (username: root, password: kosong)
3. Klik "Import" di menu atas
4. Pilih file: database/database.sql
5. Klik "Go"
```

### 4. Verifikasi Database

Pastikan database sudah dibuat dengan benar:

```bash
mysql -u root -p
USE sistem_absensi_sekolah;
SHOW TABLES;
SHOW DATABASES;

# Output seharusnya:
# Database 'sistem_absensi_sekolah' sudah ada
# 8 tabel: users, teachers, classes, students, subjects, schedules, attendance_sessions, attendance_details
```

### 5. Konfigurasi Database di PHP (Jika Diperlukan)

Edit file `config/database.php`:

```php
<?php
// Database configuration
$host = 'localhost';      // Biasanya: localhost
$username = 'root';       // Username MySQL
$password = '';           // Password MySQL (kosong jika belum diset)
$database = 'sistem_absensi_sekolah';  // Nama database

// Koneksi
$mysqli = new mysqli($host, $username, $password, $database);

// ... rest of code
?>
```

### 6. Testing Koneksi (Optional)

Buat file `test_connection.php` di root folder:

```php
<?php
require_once 'config/database.php';

if ($mysqli->connect_error) {
    echo "Koneksi gagal: " . $mysqli->connect_error;
    exit;
}

echo "Koneksi berhasil!<br>";
echo "Database: " . $mysqli->database . "<br>";

// Test select
$result = $mysqli->query("SELECT COUNT(*) as count FROM users");
$row = $result->fetch_assoc();
echo "Total Users: " . $row['count'];

$mysqli->close();
?>
```

Akses: `http://localhost/sistem_absensi/test_connection.php`

Jika berhasil, hapus file ini untuk keamanan.

### 7. Akses Aplikasi

Buka browser dan akses:
```
http://localhost/sistem_absensi
```

Jika semua lancar, Anda akan diarahkan ke halaman login.

## Login Pertama Kali

Gunakan akun default yang sudah tersedia di database:

### Akun Admin
- **Username**: `admin`
- **Password**: `admin123`
- **Role**: Admin (Akses penuh ke semua menu)

### Akun Guru
Pilih salah satu:
- **Username**: `budi` / `siti` / `ahmad` / `dewi`
- **Password**: `guru123`
- **Role**: Guru (Akses terbatas)

> ⚠️ **PENTING**: Ubah password semua akun setelah login pertama kali!

## Perubahan Password

### Untuk Admin
1. Login sebagai admin
2. Tidak ada menu "Ubah Password" di versi ini
3. Ubah langsung di database:

```sql
UPDATE users 
SET password = '$2y$10$Xvw2L6K8nZ9qH4jM3pL5Y.E8Rz5K2nL9pO7q6R5s4T3u2V1w0X'
WHERE username = 'admin';
-- Password diatas adalah hash untuk "newpassword123"
```

Untuk generate hash password, jalankan PHP script:
```php
<?php
$password = 'password_baru';
$hash = password_hash($password, PASSWORD_BCRYPT);
echo $hash;
?>
```

### Untuk Guru
Saat ini belum ada fitur ubah password. Hubungi admin untuk ubah password.

## Verifikasi Instalasi Lengkap

Setelah instalasi, periksa daftar berikut:

### 1. Struktur Folder ✅
```
sistem_absensi/
├── auth/
├── admin/
├── teacher/
├── config/
├── templates/
├── assets/
├── database/
├── index.php
├── README.md
└── INSTALLATION.md
```

### 2. Database Tables ✅
Jalankan di MySQL:
```sql
SHOW TABLES FROM sistem_absensi_sekolah;
```

Harus ada 8 tabel:
- users
- teachers
- classes
- students
- subjects
- schedules
- attendance_sessions
- attendance_details

### 3. Login Test ✅
```
Admin: admin / admin123
Guru 1: budi / guru123
Guru 2: siti / guru123
Guru 3: ahmad / guru123
Guru 4: dewi / guru123
```

### 4. Menu Navigation ✅
Setelah login:
- Admin harus bisa akses semua menu di sidebar
- Guru hanya bisa akses Dashboard dan Absensi

### 5. Fitur CRUD ✅
Coba buat/edit/hapus data:
- Data Siswa
- Data Guru
- Data Kelas
- Data Mata Pelajaran
- Data Jadwal

### 6. Fitur Absensi ✅
Guru:
1. Login sebagai guru
2. Masuk ke "Input Absensi"
3. Pilih jadwal
4. Pilih tanggal
5. Input status absensi siswa
6. Simpan

Admin:
1. Lihat laporan absensi
2. Export CSV
3. Lihat detail

## Troubleshooting

### Error 404 Not Found
```
Solusi:
1. Pastikan web server running
2. Periksa alamat URL: http://localhost/sistem_absensi
3. Pastikan folder berada di root directory web server
4. Restart web server
```

### Error: "Connection refused" atau "Can't connect to MySQL"
```
Solusi:
1. Pastikan MySQL service running
   - Windows: Buka Services, cari MySQL, start
   - Linux: sudo systemctl start mysql
2. Periksa username/password di config/database.php
3. Pastikan database sudah diimport
4. Test connection dengan test_connection.php
```

### Error: "Table doesn't exist"
```
Solusi:
1. Pastikan database.sql sudah diimport
2. Jalankan ulang import database
3. Periksa apakah ada error saat import
4. Gunakan phpMyAdmin untuk verify tables
```

### White Page atau Error 500
```
Solusi:
1. Enable error reporting di PHP
2. Cek error log web server:
   - Apache Windows: C:\xampp\apache\logs\error.log
   - Apache Linux: /var/log/apache2/error.log
   - Nginx: /var/log/nginx/error.log
3. Cek syntax PHP dengan: php -l filename.php
4. Restart web server
```

### Login gagal (Username/Password salah)
```
Solusi:
1. Pastikan database import dengan data default
2. Check users table: SELECT * FROM users;
3. Reset password dengan SQL di atas
4. Pastikan password hashing benar
```

### Sidebar menu tidak muncul
```
Solusi:
1. Clear browser cache (Ctrl+Shift+Delete)
2. Periksa console browser (F12 → Console)
3. Pastikan Bootstrap CSS CDN aktif
4. Pastikan header.php include dengan benar
```

### Export CSV tidak berfungsi
```
Solusi:
1. Periksa error di browser console
2. Pastikan tidak ada output sebelum header()
3. Periksa spesifikasi file CSV (UTF-8, semicolon delimiter)
4. Test dengan berbagai browser
```

## Environment Variables (Optional)

Buat file `.env` di root folder untuk keamanan:

```
DB_HOST=localhost
DB_USER=root
DB_PASS=password
DB_NAME=sistem_absensi_sekolah
```

Kemudian di `config/database.php`:

```php
$dotenv = parse_ini_file(__DIR__ . '/../.env');
$host = $dotenv['DB_HOST'];
$username = $dotenv['DB_USER'];
$password = $dotenv['DB_PASS'];
$database = $dotenv['DB_NAME'];
```

## Security Recommendations

1. **Change Default Passwords**: Ubah semua password default segera setelah instalasi
2. **Set Proper Permissions**: 
   ```bash
   chmod 755 admin/ teacher/ auth/ config/
   chmod 644 *.php
   ```
3. **Disable Error Display di Production**:
   Edit `config/database.php`:
   ```php
   ini_set('display_errors', 0);
   error_reporting(E_ALL);
   ```
4. **Enable HTTPS**: Gunakan SSL certificate di production
5. **Database Backup**: Buat backup regular dengan cron job:
   ```bash
   0 2 * * * mysqldump -u root -p[password] sistem_absensi_sekolah > /backup/backup_$(date +\%Y\%m\%d).sql
   ```

## Next Steps

Setelah instalasi berhasil:

1. **Login** sebagai admin
2. **Setup Master Data**:
   - Verifikasi data guru, siswa, kelas, mapel sudah ada
   - Jika tidak, tambahkan melalui menu admin
3. **Create Schedules**: Buat jadwal mengajar
4. **Add Guru Accounts**: Create user untuk setiap guru
5. **Test Workflow**: 
   - Login sebagai guru
   - Input attendance
   - Lihat laporan sebagai admin
6. **Backup Database**: Jangan lupa backup setelah setup

## Support

Untuk bantuan lebih lanjut:
- Cek README.md untuk fitur lengkap
- Periksa folder comments di setiap file PHP
- Hubungi tim development

---

**Created**: 2024  
**Maintained**: Development Team  
**Status**: Production Ready
